import 'package:flutter/material.dart';
import '../presentation/appointment_scheduler/appointment_scheduler.dart';
import '../presentation/patient_search/patient_search.dart';
import '../presentation/splash_screen/splash_screen.dart';
import '../presentation/patient_profile/patient_profile.dart';
import '../presentation/medical_records/medical_records.dart';
import '../presentation/biometric_login_screen/biometric_login_screen.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String appointmentScheduler = '/appointment-scheduler';
  static const String patientSearch = '/patient-search';
  static const String splash = '/splash-screen';
  static const String patientProfile = '/patient-profile';
  static const String medicalRecords = '/medical-records';
  static const String biometricLogin = '/biometric-login-screen';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const SplashScreen(),
    appointmentScheduler: (context) => const AppointmentScheduler(),
    patientSearch: (context) => const PatientSearch(),
    splash: (context) => const SplashScreen(),
    patientProfile: (context) => const PatientProfile(),
    medicalRecords: (context) => const MedicalRecords(),
    biometricLogin: (context) => const BiometricLoginScreen(),
    // TODO: Add your other routes here
  };
}
