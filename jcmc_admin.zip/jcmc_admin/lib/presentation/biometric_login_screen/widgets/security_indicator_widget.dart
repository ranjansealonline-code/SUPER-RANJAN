import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class SecurityIndicatorWidget extends StatefulWidget {
  final bool isSecureConnection;
  final bool isHipaaCompliant;

  const SecurityIndicatorWidget({
    Key? key,
    required this.isSecureConnection,
    required this.isHipaaCompliant,
  }) : super(key: key);

  @override
  State<SecurityIndicatorWidget> createState() =>
      _SecurityIndicatorWidgetState();
}

class _SecurityIndicatorWidgetState extends State<SecurityIndicatorWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(
      begin: 0.3,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    _animationController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 1.5.h),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface.withValues(alpha: 0.8),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.1),
          width: 1,
        ),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedBuilder(
            animation: _fadeAnimation,
            builder: (context, child) {
              return Opacity(
                opacity: widget.isSecureConnection ? _fadeAnimation.value : 0.5,
                child: CustomIconWidget(
                  iconName: widget.isSecureConnection ? 'security' : 'security',
                  color: widget.isSecureConnection
                      ? AppTheme.lightTheme.colorScheme.tertiary
                      : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  size: 4.w,
                ),
              );
            },
          ),
          SizedBox(width: 2.w),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                widget.isSecureConnection
                    ? 'Secure Connection'
                    : 'Connecting...',
                style: AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: widget.isSecureConnection
                      ? AppTheme.lightTheme.colorScheme.tertiary
                      : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
              if (widget.isHipaaCompliant)
                Text(
                  'HIPAA Compliant',
                  style: AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                    fontSize: 9.sp,
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                ),
            ],
          ),
          SizedBox(width: 3.w),
          CustomIconWidget(
            iconName: 'verified_user',
            color: widget.isHipaaCompliant
                ? AppTheme.lightTheme.colorScheme.tertiary
                : AppTheme.lightTheme.colorScheme.onSurfaceVariant,
            size: 3.5.w,
          ),
        ],
      ),
    );
  }
}
