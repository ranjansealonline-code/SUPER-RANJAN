import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:local_auth/local_auth.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/biometric_prompt_widget.dart';
import './widgets/emergency_access_widget.dart';
import './widgets/fallback_pin_widget.dart';
import './widgets/hospital_logo_widget.dart';
import './widgets/security_indicator_widget.dart';

class BiometricLoginScreen extends StatefulWidget {
  const BiometricLoginScreen({Key? key}) : super(key: key);

  @override
  State<BiometricLoginScreen> createState() => _BiometricLoginScreenState();
}

class _BiometricLoginScreenState extends State<BiometricLoginScreen>
    with TickerProviderStateMixin {
  final LocalAuthentication _localAuth = LocalAuthentication();

  bool _isLoading = false;
  bool _showPinFallback = false;
  bool _isSecureConnection = true;
  bool _isHipaaCompliant = true;
  String _biometricType = 'fingerprint';
  String? _pinErrorMessage;
  int _failedAttempts = 0;
  bool _isEmergencyLoading = false;

  // Mock credentials for different user roles
  final Map<String, Map<String, dynamic>> _mockCredentials = {
    'admin_pin': {
      'pin': '123456',
      'role': 'administrator',
      'name': 'Dr. Sarah Johnson',
      'department': 'Administration',
      'route': '/patient-search'
    },
    'doctor_pin': {
      'pin': '789012',
      'role': 'doctor',
      'name': 'Dr. Michael Chen',
      'department': 'Cardiology',
      'route': '/patient-profile'
    },
    'nurse_pin': {
      'pin': '345678',
      'role': 'nurse',
      'name': 'Nurse Emily Davis',
      'department': 'ICU',
      'route': '/medical-records'
    },
    'reception_pin': {
      'pin': '901234',
      'role': 'reception',
      'name': 'Ms. Priya Sharma',
      'department': 'Front Desk',
      'route': '/appointment-scheduler'
    }
  };

  @override
  void initState() {
    super.initState();
    _initializeBiometric();
  }

  Future<void> _initializeBiometric() async {
    try {
      final bool isAvailable = await _localAuth.isDeviceSupported();
      final bool canCheckBiometrics = await _localAuth.canCheckBiometrics;

      if (isAvailable && canCheckBiometrics) {
        final List<BiometricType> availableBiometrics =
            await _localAuth.getAvailableBiometrics();

        if (availableBiometrics.contains(BiometricType.face)) {
          setState(() {
            _biometricType = 'face';
          });
        } else if (availableBiometrics.contains(BiometricType.fingerprint)) {
          setState(() {
            _biometricType = 'fingerprint';
          });
        }
      }
    } catch (e) {
      debugPrint('Biometric initialization error: $e');
    }
  }

  Future<void> _authenticateWithBiometric() async {
    setState(() {
      _isLoading = true;
      _pinErrorMessage = null;
    });

    try {
      final bool didAuthenticate = await _localAuth.authenticate(
        localizedReason: 'Please authenticate to access JCMC Admin',
        options: const AuthenticationOptions(
          biometricOnly: false,
          stickyAuth: true,
        ),
      );

      if (didAuthenticate) {
        HapticFeedback.lightImpact();
        await _navigateToRoleBasedScreen('administrator');
      } else {
        setState(() {
          _failedAttempts++;
          if (_failedAttempts >= 3) {
            _showPinFallback = true;
          }
        });
        _showErrorMessage('Authentication failed. Please try again.');
      }
    } catch (e) {
      setState(() {
        _failedAttempts++;
        if (_failedAttempts >= 2) {
          _showPinFallback = true;
        }
      });
      _showErrorMessage(
          'Biometric authentication unavailable. Use PIN instead.');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _authenticateWithPin(String pin) async {
    setState(() {
      _isLoading = true;
      _pinErrorMessage = null;
    });

    await Future.delayed(const Duration(milliseconds: 1500));

    // Check against mock credentials
    String? matchedRole;
    Map<String, dynamic>? userInfo;

    for (String key in _mockCredentials.keys) {
      if (_mockCredentials[key]!['pin'] == pin) {
        matchedRole = _mockCredentials[key]!['role'];
        userInfo = _mockCredentials[key]!;
        break;
      }
    }

    if (matchedRole != null && userInfo != null) {
      HapticFeedback.lightImpact();
      Fluttertoast.showToast(
        msg: 'Welcome, ${userInfo['name']}!',
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
      );
      await _navigateToRoleBasedScreen(matchedRole);
    } else {
      setState(() {
        _pinErrorMessage = 'Invalid PIN. Please try again.';
        _failedAttempts++;
      });
      HapticFeedback.heavyImpact();
    }

    setState(() {
      _isLoading = false;
    });
  }

  Future<void> _handleEmergencyAccess() async {
    setState(() {
      _isEmergencyLoading = true;
    });

    await Future.delayed(const Duration(milliseconds: 2000));

    // Log emergency access for audit compliance
    debugPrint('Emergency access granted at ${DateTime.now()}');

    Fluttertoast.showToast(
      msg: 'Emergency access granted. Limited functionality available.',
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.BOTTOM,
    );

    setState(() {
      _isEmergencyLoading = false;
    });

    // Navigate to limited emergency interface
    Navigator.pushReplacementNamed(context, '/patient-search');
  }

  Future<void> _navigateToRoleBasedScreen(String role) async {
    await Future.delayed(const Duration(milliseconds: 500));

    String route;
    switch (role) {
      case 'administrator':
        route = '/patient-search';
        break;
      case 'doctor':
        route = '/patient-profile';
        break;
      case 'nurse':
        route = '/medical-records';
        break;
      case 'reception':
        route = '/appointment-scheduler';
        break;
      default:
        route = '/patient-search';
    }

    Navigator.pushReplacementNamed(context, route);
  }

  void _showErrorMessage(String message) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      backgroundColor: AppTheme.lightTheme.colorScheme.error,
      textColor: AppTheme.lightTheme.colorScheme.onError,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Container(
            width: double.infinity,
            constraints: BoxConstraints(
              minHeight: 100.h -
                  MediaQuery.of(context).padding.top -
                  MediaQuery.of(context).padding.bottom,
            ),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  AppTheme.lightTheme.scaffoldBackgroundColor,
                  AppTheme.lightTheme.colorScheme.surface
                      .withValues(alpha: 0.5),
                ],
              ),
            ),
            child: Column(
              children: [
                SizedBox(height: 4.h),

                // Security Indicator
                Align(
                  alignment: Alignment.centerRight,
                  child: Padding(
                    padding: EdgeInsets.only(right: 6.w),
                    child: SecurityIndicatorWidget(
                      isSecureConnection: _isSecureConnection,
                      isHipaaCompliant: _isHipaaCompliant,
                    ),
                  ),
                ),

                SizedBox(height: 3.h),

                // Hospital Logo
                const HospitalLogoWidget(),

                SizedBox(height: 6.h),

                // Biometric Prompt (shown when PIN fallback is not active)
                if (!_showPinFallback) ...[
                  BiometricPromptWidget(
                    onAuthenticate: _authenticateWithBiometric,
                    isLoading: _isLoading,
                    biometricType: _biometricType,
                  ),

                  SizedBox(height: 4.h),

                  // Switch to PIN option
                  TextButton(
                    onPressed: _isLoading
                        ? null
                        : () {
                            setState(() {
                              _showPinFallback = true;
                            });
                          },
                    child: Text(
                      'Use PIN instead',
                      style:
                          AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.primary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],

                // PIN Fallback (shown when biometric fails or user chooses PIN)
                if (_showPinFallback) ...[
                  FallbackPinWidget(
                    onPinEntered: _authenticateWithPin,
                    isLoading: _isLoading,
                    errorMessage: _pinErrorMessage,
                  ),

                  SizedBox(height: 3.h),

                  // Switch back to biometric option
                  TextButton(
                    onPressed: _isLoading
                        ? null
                        : () {
                            setState(() {
                              _showPinFallback = false;
                              _pinErrorMessage = null;
                              _failedAttempts = 0;
                            });
                          },
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CustomIconWidget(
                          iconName:
                              _biometricType == 'face' ? 'face' : 'fingerprint',
                          color: AppTheme.lightTheme.colorScheme.primary,
                          size: 4.w,
                        ),
                        SizedBox(width: 2.w),
                        Text(
                          'Use ${_biometricType == 'face' ? 'Face ID' : 'Fingerprint'} instead',
                          style: AppTheme.lightTheme.textTheme.labelMedium
                              ?.copyWith(
                            color: AppTheme.lightTheme.colorScheme.primary,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],

                SizedBox(height: 6.h),

                // Emergency Access
                EmergencyAccessWidget(
                  onEmergencyAccess: _handleEmergencyAccess,
                  isLoading: _isEmergencyLoading,
                ),

                SizedBox(height: 4.h),

                // Footer Information
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8.w),
                  child: Column(
                    children: [
                      Text(
                        'Secure authentication ensures HIPAA compliance and protects patient data',
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 1.h),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomIconWidget(
                            iconName: 'shield',
                            color: AppTheme.lightTheme.colorScheme.tertiary,
                            size: 3.w,
                          ),
                          SizedBox(width: 1.w),
                          Text(
                            'Medical Grade Security',
                            style: AppTheme.lightTheme.textTheme.labelSmall
                                ?.copyWith(
                              color: AppTheme.lightTheme.colorScheme.tertiary,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 2.h),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
