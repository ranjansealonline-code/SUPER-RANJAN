import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class TimeSlotGridWidget extends StatelessWidget {
  final DateTime selectedDate;
  final List<Map<String, dynamic>> timeSlots;
  final Function(Map<String, dynamic>) onSlotSelected;
  final Function(Map<String, dynamic>) onSlotLongPress;

  const TimeSlotGridWidget({
    Key? key,
    required this.selectedDate,
    required this.timeSlots,
    required this.onSlotSelected,
    required this.onSlotLongPress,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildHeader(),
          SizedBox(height: 2.h),
          _buildTimeSlotGrid(),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        CustomIconWidget(
          iconName: 'schedule',
          color: AppTheme.lightTheme.colorScheme.primary,
          size: 20,
        ),
        SizedBox(width: 2.w),
        Text(
          'Available Time Slots',
          style: TextStyle(
            fontSize: 14.sp,
            fontWeight: FontWeight.w600,
            color: AppTheme.lightTheme.colorScheme.onSurface,
          ),
        ),
        const Spacer(),
        Text(
          _formatDate(selectedDate),
          style: TextStyle(
            fontSize: 12.sp,
            color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          ),
        ),
      ],
    );
  }

  Widget _buildTimeSlotGrid() {
    if (timeSlots.isEmpty) {
      return Container(
        height: 20.h,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomIconWidget(
                iconName: 'event_busy',
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                size: 32,
              ),
              SizedBox(height: 1.h),
              Text(
                'No appointments available',
                style: TextStyle(
                  fontSize: 12.sp,
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        childAspectRatio: 2.5,
        crossAxisSpacing: 3.w,
        mainAxisSpacing: 2.h,
      ),
      itemCount: timeSlots.length,
      itemBuilder: (context, index) {
        final slot = timeSlots[index];
        return _buildTimeSlotCard(slot);
      },
    );
  }

  Widget _buildTimeSlotCard(Map<String, dynamic> slot) {
    final isAvailable = slot['status'] == 'available';
    final isBooked = slot['status'] == 'booked';
    final isTentative = slot['status'] == 'tentative';

    Color backgroundColor;
    Color borderColor;
    Color textColor;

    if (isAvailable) {
      backgroundColor = Colors.green.withValues(alpha: 0.1);
      borderColor = Colors.green;
      textColor = Colors.green.shade700;
    } else if (isBooked) {
      backgroundColor = Colors.red.withValues(alpha: 0.1);
      borderColor = Colors.red;
      textColor = Colors.red.shade700;
    } else if (isTentative) {
      backgroundColor = Colors.orange.withValues(alpha: 0.1);
      borderColor = Colors.orange;
      textColor = Colors.orange.shade700;
    } else {
      backgroundColor = AppTheme.lightTheme.colorScheme.surface;
      borderColor = AppTheme.lightTheme.colorScheme.outline;
      textColor = AppTheme.lightTheme.colorScheme.onSurfaceVariant;
    }

    return GestureDetector(
      onTap: isAvailable ? () => onSlotSelected(slot) : null,
      onLongPress: !isAvailable ? () => onSlotLongPress(slot) : null,
      child: Container(
        padding: EdgeInsets.all(3.w),
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: borderColor, width: 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  slot['time'] as String,
                  style: TextStyle(
                    fontSize: 12.sp,
                    fontWeight: FontWeight.w600,
                    color: textColor,
                  ),
                ),
                _buildStatusIcon(slot['status'] as String),
              ],
            ),
            if (slot['doctorName'] != null) ...[
              SizedBox(height: 0.5.h),
              Text(
                'Dr. ${slot['doctorName']}',
                style: TextStyle(
                  fontSize: 10.sp,
                  fontWeight: FontWeight.w500,
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                ),
                overflow: TextOverflow.ellipsis,
              ),
              if (slot['specialty'] != null)
                Text(
                  slot['specialty'] as String,
                  style: TextStyle(
                    fontSize: 9.sp,
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildStatusIcon(String status) {
    switch (status) {
      case 'available':
        return CustomIconWidget(
          iconName: 'check_circle',
          color: Colors.green,
          size: 16,
        );
      case 'booked':
        return CustomIconWidget(
          iconName: 'cancel',
          color: Colors.red,
          size: 16,
        );
      case 'tentative':
        return CustomIconWidget(
          iconName: 'schedule',
          color: Colors.orange,
          size: 16,
        );
      default:
        return CustomIconWidget(
          iconName: 'help_outline',
          color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
          size: 16,
        );
    }
  }

  String _formatDate(DateTime date) {
    final months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec'
    ];
    return '${date.day} ${months[date.month - 1]}, ${date.year}';
  }
}
