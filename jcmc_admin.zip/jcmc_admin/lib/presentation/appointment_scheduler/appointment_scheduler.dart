import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/appointment_booking_sheet.dart';
import './widgets/calendar_widget.dart';
import './widgets/patient_search_sheet.dart';
import './widgets/patient_selector_widget.dart';
import './widgets/time_slot_grid_widget.dart';

class AppointmentScheduler extends StatefulWidget {
  const AppointmentScheduler({Key? key}) : super(key: key);

  @override
  State<AppointmentScheduler> createState() => _AppointmentSchedulerState();
}

class _AppointmentSchedulerState extends State<AppointmentScheduler> {
  DateTime _selectedDate = DateTime.now();
  Map<String, dynamic>? _selectedPatient;
  Map<DateTime, List<Map<String, dynamic>>> _appointments = {};
  List<Map<String, dynamic>> _timeSlots = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _initializeAppointments();
    _generateTimeSlotsForDate(_selectedDate);
  }

  void _initializeAppointments() {
    final today = DateTime.now();
    final tomorrow = today.add(const Duration(days: 1));
    final dayAfterTomorrow = today.add(const Duration(days: 2));

    _appointments = {
      DateTime(today.year, today.month, today.day): [
        {
          'time': '09:00 AM',
          'doctorName': 'Sarah Johnson',
          'specialty': 'Cardiology',
          'status': 'confirmed',
          'patientName': 'John Doe',
        },
        {
          'time': '02:30 PM',
          'doctorName': 'Michael Chen',
          'specialty': 'Neurology',
          'status': 'tentative',
          'patientName': 'Jane Smith',
        },
      ],
      DateTime(tomorrow.year, tomorrow.month, tomorrow.day): [
        {
          'time': '10:15 AM',
          'doctorName': 'Emily Davis',
          'specialty': 'Pediatrics',
          'status': 'confirmed',
          'patientName': 'Bobby Wilson',
        },
      ],
      DateTime(dayAfterTomorrow.year, dayAfterTomorrow.month,
          dayAfterTomorrow.day): [
        {
          'time': '11:00 AM',
          'doctorName': 'Robert Kumar',
          'specialty': 'Orthopedics',
          'status': 'confirmed',
          'patientName': 'Alice Brown',
        },
      ],
    };
  }

  void _generateTimeSlotsForDate(DateTime date) {
    setState(() {
      _isLoading = true;
    });

    // Simulate loading delay
    Future.delayed(const Duration(milliseconds: 500), () {
      final slots = <Map<String, dynamic>>[];
      final dateKey = DateTime(date.year, date.month, date.day);
      final existingAppointments = _appointments[dateKey] ?? [];

      // Generate time slots from 9 AM to 5 PM
      final startHour = 9;
      final endHour = 17;
      final doctors = [
        {'name': 'Sarah Johnson', 'specialty': 'Cardiology'},
        {'name': 'Michael Chen', 'specialty': 'Neurology'},
        {'name': 'Emily Davis', 'specialty': 'Pediatrics'},
        {'name': 'Robert Kumar', 'specialty': 'Orthopedics'},
        {'name': 'Lisa Patel', 'specialty': 'Dermatology'},
      ];

      for (int hour = startHour; hour < endHour; hour++) {
        for (int minute = 0; minute < 60; minute += 30) {
          final timeString = _formatTime(hour, minute);
          final doctor = doctors[
              ((hour - startHour) * 2 + (minute ~/ 30)) % doctors.length];

          // Check if this slot is already booked
          final isBooked =
              existingAppointments.any((apt) => apt['time'] == timeString);

          slots.add({
            'time': timeString,
            'doctorName': doctor['name'],
            'specialty': doctor['specialty'],
            'status': isBooked ? 'booked' : 'available',
          });
        }
      }

      setState(() {
        _timeSlots = slots;
        _isLoading = false;
      });
    });
  }

  String _formatTime(int hour, int minute) {
    final period = hour >= 12 ? 'PM' : 'AM';
    final displayHour = hour > 12 ? hour - 12 : (hour == 0 ? 12 : hour);
    final minuteString = minute.toString().padLeft(2, '0');
    return '$displayHour:$minuteString $period';
  }

  void _onDateSelected(DateTime date) {
    setState(() {
      _selectedDate = date;
    });
    _generateTimeSlotsForDate(date);
  }

  void _onPatientTap() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => PatientSearchSheet(
        onPatientSelected: (patient) {
          setState(() {
            _selectedPatient = patient;
          });
        },
      ),
    );
  }

  void _onSlotSelected(Map<String, dynamic> slot) {
    if (_selectedPatient == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select a patient first'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => AppointmentBookingSheet(
        selectedSlot: slot,
        selectedPatient: _selectedPatient,
        onBookingConfirmed: _onBookingConfirmed,
      ),
    );
  }

  void _onSlotLongPress(Map<String, dynamic> slot) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildAppointmentManagementSheet(slot),
    );
  }

  Widget _buildAppointmentManagementSheet(Map<String, dynamic> slot) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              CustomIconWidget(
                iconName: 'event',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 24,
              ),
              SizedBox(width: 3.w),
              Text(
                'Manage Appointment',
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          _buildManagementOption('Reschedule', 'schedule', () {
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                  content: Text('Reschedule functionality coming soon')),
            );
          }),
          _buildManagementOption('Cancel Appointment', 'cancel', () {
            Navigator.pop(context);
            _cancelAppointment(slot);
          }),
          _buildManagementOption('Add Notes', 'note_add', () {
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                  content: Text('Add notes functionality coming soon')),
            );
          }),
          _buildManagementOption('Contact Patient', 'phone', () {
            Navigator.pop(context);
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                  content: Text('Contact patient functionality coming soon')),
            );
          }),
          SizedBox(height: 2.h),
        ],
      ),
    );
  }

  Widget _buildManagementOption(
      String title, String iconName, VoidCallback onTap) {
    return ListTile(
      leading: CustomIconWidget(
        iconName: iconName,
        color: AppTheme.lightTheme.colorScheme.primary,
        size: 24,
      ),
      title: Text(
        title,
        style: TextStyle(
          fontSize: 13.sp,
          fontWeight: FontWeight.w500,
          color: AppTheme.lightTheme.colorScheme.onSurface,
        ),
      ),
      onTap: onTap,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
      ),
    );
  }

  void _onBookingConfirmed(Map<String, dynamic> bookingData) {
    final dateKey =
        DateTime(_selectedDate.year, _selectedDate.month, _selectedDate.day);

    setState(() {
      if (!_appointments.containsKey(dateKey)) {
        _appointments[dateKey] = [];
      }

      _appointments[dateKey]!.add({
        'time': bookingData['slot']['time'],
        'doctorName': bookingData['slot']['doctorName'],
        'specialty': bookingData['slot']['specialty'],
        'status': 'confirmed',
        'patientName': bookingData['patient']['name'],
        'appointmentType': bookingData['appointmentType'],
        'duration': bookingData['duration'],
        'notes': bookingData['notes'],
      });
    });

    _generateTimeSlotsForDate(_selectedDate);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
            'Appointment booked successfully for ${bookingData['patient']['name']}'),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _cancelAppointment(Map<String, dynamic> slot) {
    final dateKey =
        DateTime(_selectedDate.year, _selectedDate.month, _selectedDate.day);

    setState(() {
      if (_appointments.containsKey(dateKey)) {
        _appointments[dateKey]!
            .removeWhere((apt) => apt['time'] == slot['time']);
        if (_appointments[dateKey]!.isEmpty) {
          _appointments.remove(dateKey);
        }
      }
    });

    _generateTimeSlotsForDate(_selectedDate);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Appointment cancelled successfully'),
        backgroundColor: Colors.red,
      ),
    );
  }

  void _showEmergencyScheduling() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            CustomIconWidget(
              iconName: 'emergency',
              color: Colors.red,
              size: 24,
            ),
            SizedBox(width: 2.w),
            const Text('Emergency Scheduling'),
          ],
        ),
        content: const Text(
            'Emergency scheduling will override existing appointments and notify all relevant staff.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content:
                      Text('Emergency scheduling functionality coming soon'),
                  backgroundColor: Colors.orange,
                ),
              );
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Proceed', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Appointment Scheduler'),
        actions: [
          IconButton(
            onPressed: () => Navigator.pushNamed(context, '/patient-search'),
            icon: CustomIconWidget(
              iconName: 'search',
              color: AppTheme.lightTheme.colorScheme.onSurface,
              size: 24,
            ),
          ),
          IconButton(
            onPressed: () => Navigator.pushNamed(context, '/medical-records'),
            icon: CustomIconWidget(
              iconName: 'folder_shared',
              color: AppTheme.lightTheme.colorScheme.onSurface,
              size: 24,
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            PatientSelectorWidget(
              selectedPatient: _selectedPatient,
              onPatientTap: _onPatientTap,
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.all(4.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CalendarWidget(
                      selectedDate: _selectedDate,
                      onDateSelected: _onDateSelected,
                      appointments: _appointments,
                    ),
                    SizedBox(height: 3.h),
                    _isLoading
                        ? Container(
                            height: 30.h,
                            child: const Center(
                              child: CircularProgressIndicator(),
                            ),
                          )
                        : TimeSlotGridWidget(
                            selectedDate: _selectedDate,
                            timeSlots: _timeSlots,
                            onSlotSelected: _onSlotSelected,
                            onSlotLongPress: _onSlotLongPress,
                          ),
                    SizedBox(height: 10.h),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showEmergencyScheduling,
        icon: CustomIconWidget(
          iconName: 'emergency',
          color: Colors.white,
          size: 20,
        ),
        label: const Text(
          'Emergency',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.red,
      ),
    );
  }
}
