import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/date_range_selector.dart';
import './widgets/patient_header_widget.dart';
import './widgets/quick_documentation_sheet.dart';
import './widgets/record_entry_card.dart';
import './widgets/record_tab_bar.dart';
import './widgets/search_filter_sheet.dart';

class MedicalRecords extends StatefulWidget {
  const MedicalRecords({Key? key}) : super(key: key);

  @override
  State<MedicalRecords> createState() => _MedicalRecordsState();
}

class _MedicalRecordsState extends State<MedicalRecords>
    with TickerProviderStateMixin {
  late TabController _tabController;
  DateTime _startDate = DateTime.now().subtract(const Duration(days: 30));
  DateTime _endDate = DateTime.now();
  Map<String, dynamic> _currentFilters = {};
  String? _expandedRecordId;
  bool _isLoading = false;

  // Mock patient data
  final Map<String, dynamic> _patientData = {
    "patientId": "JCMC-2024-001234",
    "name": "Rajesh Kumar Sharma",
    "age": "45",
    "gender": "Male",
    "avatar":
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
  };

  // Mock medical records data
  final List<Map<String, dynamic>> _allRecords = [
    {
      "id": "rec_001",
      "type": "progress_note",
      "date": "21/08/2025",
      "physician": "Sarah Johnson",
      "summary":
          "Patient presents with acute abdominal pain in the right lower quadrant. Vital signs stable.",
      "fullText":
          "Patient presents with acute abdominal pain in the right lower quadrant that started approximately 6 hours ago. Pain is sharp, constant, and worsens with movement. No nausea or vomiting reported. Patient denies fever or chills. Physical examination reveals tenderness in McBurney's point with positive rebound tenderness. Vital signs remain stable throughout examination.",
      "vitals": {
        "Blood Pressure": "120/80 mmHg",
        "Heart Rate": "88 bpm",
        "Temperature": "37.2°C",
        "Respiratory Rate": "16/min",
        "O2 Saturation": "98%"
      },
      "treatment":
          "Recommended CT scan to rule out appendicitis. NPO status maintained. IV fluids initiated. Pain management with morphine 2mg IV PRN. Surgical consultation requested.",
      "status": "critical",
      "condition": "Abdominal Pain",
      "treatmentType": "Diagnostic Tests"
    },
    {
      "id": "rec_002",
      "type": "lab_result",
      "date": "20/08/2025",
      "physician": "Michael Chen",
      "summary":
          "Complete Blood Count shows elevated white cell count at 12,500/μL indicating possible infection.",
      "fullText":
          "Laboratory results from morning draw show: WBC 12,500/μL (elevated), RBC 4.2 million/μL (normal), Hemoglobin 13.8 g/dL (normal), Hematocrit 41% (normal), Platelets 285,000/μL (normal). Differential shows 78% neutrophils with left shift suggesting bacterial infection.",
      "vitals": {},
      "treatment":
          "Continue antibiotic therapy. Repeat CBC in 48 hours to monitor response to treatment.",
      "status": "abnormal",
      "condition": "Infection",
      "treatmentType": "Medication"
    },
    {
      "id": "rec_003",
      "type": "imaging",
      "date": "19/08/2025",
      "physician": "Emily Rodriguez",
      "summary":
          "Chest X-ray shows clear lung fields with no signs of pneumonia or other abnormalities.",
      "fullText":
          "Chest X-ray PA and lateral views obtained. Lung fields are clear bilaterally with no evidence of consolidation, pleural effusion, or pneumothorax. Heart size is within normal limits. No acute cardiopulmonary abnormalities identified. Comparison with previous imaging from 6 months ago shows no significant changes.",
      "vitals": {},
      "treatment":
          "No immediate intervention required. Continue current respiratory care plan.",
      "status": "normal",
      "condition": "Respiratory Issues",
      "treatmentType": "Diagnostic Tests"
    },
    {
      "id": "rec_004",
      "type": "prescription",
      "date": "18/08/2025",
      "physician": "David Kumar",
      "summary":
          "Prescribed Lisinopril 10mg daily for hypertension management and lifestyle modifications.",
      "fullText":
          "Patient's blood pressure remains elevated despite lifestyle modifications over the past 3 months. Initiating ACE inhibitor therapy with Lisinopril 10mg once daily. Patient counseled on proper medication timing, potential side effects including dry cough and hyperkalemia. Emphasized importance of medication compliance.",
      "vitals": {
        "Blood Pressure": "150/95 mmHg",
        "Heart Rate": "76 bpm",
        "Weight": "78 kg"
      },
      "treatment":
          "Lisinopril 10mg PO daily. Follow-up in 4 weeks to assess response. Continue low-sodium diet and regular exercise. Monitor potassium levels in 2 weeks.",
      "status": "abnormal",
      "condition": "Hypertension",
      "treatmentType": "Medication"
    },
    {
      "id": "rec_005",
      "type": "progress_note",
      "date": "17/08/2025",
      "physician": "Lisa Thompson",
      "summary":
          "Post-operative follow-up shows excellent wound healing with no signs of infection.",
      "fullText":
          "Patient returns for post-operative follow-up 2 weeks after laparoscopic cholecystectomy. Surgical sites are healing well with no erythema, swelling, or discharge. Patient reports minimal pain, well-controlled with acetaminophen. Bowel movements have returned to normal. Patient is tolerating regular diet without nausea.",
      "vitals": {
        "Temperature": "36.8°C",
        "Blood Pressure": "118/75 mmHg",
        "Heart Rate": "72 bpm"
      },
      "treatment":
          "Continue current wound care. Resume normal activities gradually. Remove sutures in 1 week. No restrictions on diet. Follow-up in 4 weeks or PRN.",
      "status": "normal",
      "condition": "Post-surgical",
      "treatmentType": "Follow-up Care"
    },
    {
      "id": "rec_006",
      "type": "progress_note",
      "date": "15/08/2025",
      "physician": "Sarah Johnson",
      "summary":
          "Diabetes management review shows improved glucose control with HbA1c at 7.2%.",
      "fullText":
          "Patient returns for routine diabetes management visit. Reports good adherence to medication regimen and dietary modifications. Home glucose monitoring logs show improved control with fasting glucose averaging 125 mg/dL. Recent HbA1c improved from 8.5% to 7.2% over past 3 months.",
      "vitals": {
        "Blood Pressure": "128/82 mmHg",
        "Weight": "76 kg",
        "BMI": "26.8"
      },
      "treatment":
          "Continue current metformin 1000mg BID. Reinforce dietary counseling. Increase exercise to 150 minutes per week. Repeat HbA1c in 3 months. Ophthalmology referral for annual diabetic eye exam.",
      "status": "normal",
      "condition": "Diabetes",
      "treatmentType": "Medication"
    }
  ];

  List<Map<String, dynamic>> _filteredRecords = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
    _filteredRecords = List.from(_allRecords);
    _applyTabFilter();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _applyTabFilter() {
    final tabIndex = _tabController.index;
    final tabTypes = ['progress_note', 'lab_result', 'imaging', 'prescription'];

    if (tabIndex < tabTypes.length) {
      final selectedType = tabTypes[tabIndex];
      setState(() {
        _filteredRecords = _allRecords.where((record) {
          return (record['type'] as String) == selectedType;
        }).toList();
      });
    }
  }

  void _onFiltersApplied(Map<String, dynamic> filters) {
    setState(() {
      _currentFilters = filters;
      _startDate = filters['startDate'] as DateTime;
      _endDate = filters['endDate'] as DateTime;
      _isLoading = true;
    });

    // Simulate network delay
    Future.delayed(const Duration(milliseconds: 800), () {
      setState(() {
        _filteredRecords = _allRecords.where((record) {
          // Apply search query filter
          final searchQuery =
              (filters['searchQuery'] as String? ?? '').toLowerCase();
          if (searchQuery.isNotEmpty) {
            final summary = (record['summary'] as String? ?? '').toLowerCase();
            final fullText =
                (record['fullText'] as String? ?? '').toLowerCase();
            if (!summary.contains(searchQuery) &&
                !fullText.contains(searchQuery)) {
              return false;
            }
          }

          // Apply physician filter
          final physicianFilter =
              filters['physician'] as String? ?? 'All Physicians';
          if (physicianFilter != 'All Physicians') {
            final recordPhysician = record['physician'] as String? ?? '';
            if (!recordPhysician
                .contains(physicianFilter.replaceAll('Dr. ', ''))) {
              return false;
            }
          }

          // Apply condition filter
          final conditionFilter =
              filters['condition'] as String? ?? 'All Conditions';
          if (conditionFilter != 'All Conditions') {
            final recordCondition = record['condition'] as String? ?? '';
            if (recordCondition != conditionFilter) {
              return false;
            }
          }

          // Apply treatment filter
          final treatmentFilter =
              filters['treatment'] as String? ?? 'All Treatments';
          if (treatmentFilter != 'All Treatments') {
            final recordTreatment = record['treatmentType'] as String? ?? '';
            if (recordTreatment != treatmentFilter) {
              return false;
            }
          }

          return true;
        }).toList();

        _applyTabFilter();
        _isLoading = false;
      });
    });
  }

  void _showSearchFilter() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => SearchFilterSheet(
        onFiltersApplied: _onFiltersApplied,
        currentFilters: _currentFilters,
      ),
    );
  }

  void _showQuickDocumentation() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => QuickDocumentationSheet(
        onDocumentationSaved: (documentation) {
          // Add new documentation to records
          final newRecord = {
            "id": "rec_${DateTime.now().millisecondsSinceEpoch}",
            "type": "progress_note",
            "date":
                "${DateTime.now().day.toString().padLeft(2, '0')}/${DateTime.now().month.toString().padLeft(2, '0')}/${DateTime.now().year}",
            "physician": "Current User",
            "summary": documentation['notes'].toString().length > 100
                ? "${documentation['notes'].toString().substring(0, 100)}..."
                : documentation['notes'].toString(),
            "fullText": documentation['notes'].toString(),
            "vitals": documentation['vitals'] as Map<String, dynamic>,
            "treatment": documentation['treatment'].toString(),
            "status":
                documentation['isEmergency'] == true ? "critical" : "normal",
            "condition": "General",
            "treatmentType": "Documentation"
          };

          setState(() {
            _allRecords.insert(0, newRecord);
            _applyTabFilter();
          });

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Documentation saved successfully'),
              backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
            ),
          );
        },
      ),
    );
  }

  void _selectDateRange() async {
    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime.now().subtract(const Duration(days: 365 * 5)),
      lastDate: DateTime.now(),
      initialDateRange: DateTimeRange(start: _startDate, end: _endDate),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: Theme.of(context).colorScheme.copyWith(
                  primary: AppTheme.lightTheme.colorScheme.primary,
                ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate = picked.end;
      });
    }
  }

  void _toggleRecordExpansion(String recordId) {
    setState(() {
      _expandedRecordId = _expandedRecordId == recordId ? null : recordId;
    });
  }

  void _handleRecordAction(String action, Map<String, dynamic> record) {
    String message = '';
    Color backgroundColor = AppTheme.lightTheme.colorScheme.tertiary;

    switch (action) {
      case 'flag':
        message = 'Record flagged for review';
        backgroundColor = AppTheme.lightTheme.colorScheme.tertiary;
        break;
      case 'share':
        message = 'Record shared with physician';
        backgroundColor = AppTheme.lightTheme.colorScheme.primary;
        break;
      case 'print':
        message = 'Printing record summary...';
        backgroundColor = AppTheme.lightTheme.colorScheme.secondary;
        break;
      case 'archive':
        message = 'Record archived successfully';
        backgroundColor = AppTheme.lightTheme.colorScheme.secondary;
        break;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: backgroundColor,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: Column(
        children: [
          // Patient Header
          PatientHeaderWidget(
            patient: _patientData,
            onBackPressed: () => Navigator.pop(context),
            onSearchPressed: _showSearchFilter,
          ),

          // Date Range Selector
          DateRangeSelector(
            startDate: _startDate,
            endDate: _endDate,
            onDateRangePressed: _selectDateRange,
          ),

          // Tab Bar
          RecordTabBar(
            tabController: _tabController,
            tabs: const [
              'Progress Notes',
              'Lab Results',
              'Imaging',
              'Prescriptions'
            ],
          ),

          SizedBox(height: 2.h),

          // Records List
          Expanded(
            child: _isLoading
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircularProgressIndicator(
                          color: AppTheme.lightTheme.colorScheme.primary,
                        ),
                        SizedBox(height: 2.h),
                        Text(
                          'Loading medical records...',
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium
                              ?.copyWith(
                                color:
                                    AppTheme.lightTheme.colorScheme.secondary,
                              ),
                        ),
                      ],
                    ),
                  )
                : _filteredRecords.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CustomIconWidget(
                              iconName: 'description',
                              size: 15.w,
                              color: AppTheme.lightTheme.colorScheme.secondary
                                  .withValues(alpha: 0.5),
                            ),
                            SizedBox(height: 2.h),
                            Text(
                              'No records found',
                              style: Theme.of(context)
                                  .textTheme
                                  .titleMedium
                                  ?.copyWith(
                                    color: AppTheme
                                        .lightTheme.colorScheme.secondary,
                                  ),
                            ),
                            SizedBox(height: 1.h),
                            Text(
                              'Try adjusting your filters or date range',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyMedium
                                  ?.copyWith(
                                    color: AppTheme
                                        .lightTheme.colorScheme.secondary
                                        .withValues(alpha: 0.7),
                                  ),
                              textAlign: TextAlign.center,
                            ),
                          ],
                        ),
                      )
                    : TabBarView(
                        controller: _tabController,
                        children: List.generate(4, (index) {
                          return ListView.builder(
                            padding: EdgeInsets.only(bottom: 10.h),
                            itemCount: _filteredRecords.length,
                            itemBuilder: (context, index) {
                              final record = _filteredRecords[index];
                              final recordId = record['id'] as String;

                              return RecordEntryCard(
                                record: record,
                                isExpanded: _expandedRecordId == recordId,
                                onTap: () => _toggleRecordExpansion(recordId),
                                onFlag: () =>
                                    _handleRecordAction('flag', record),
                                onShare: () =>
                                    _handleRecordAction('share', record),
                                onPrint: () =>
                                    _handleRecordAction('print', record),
                                onArchive: () =>
                                    _handleRecordAction('archive', record),
                              );
                            },
                          );
                        }),
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _showQuickDocumentation,
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
        foregroundColor: Colors.white,
        icon: CustomIconWidget(
          iconName: 'add',
          size: 24,
          color: Colors.white,
        ),
        label: const Text('Add Note'),
      ),
    );
  }
}
