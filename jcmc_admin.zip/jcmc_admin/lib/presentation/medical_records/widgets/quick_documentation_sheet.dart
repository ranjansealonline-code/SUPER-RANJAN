import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';
import './voice_to_text_widget.dart';

class QuickDocumentationSheet extends StatefulWidget {
  final Function(Map<String, dynamic>) onDocumentationSaved;

  const QuickDocumentationSheet({
    Key? key,
    required this.onDocumentationSaved,
  }) : super(key: key);

  @override
  State<QuickDocumentationSheet> createState() =>
      _QuickDocumentationSheetState();
}

class _QuickDocumentationSheetState extends State<QuickDocumentationSheet>
    with TickerProviderStateMixin {
  late TabController _tabController;
  late TextEditingController _notesController;
  late TextEditingController _treatmentController;

  // Vital Signs Controllers
  late TextEditingController _bpController;
  late TextEditingController _hrController;
  late TextEditingController _tempController;
  late TextEditingController _respController;
  late TextEditingController _oxygenController;

  String _selectedNoteType = 'Progress Note';
  bool _isEmergency = false;
  bool _showVoiceInput = false;

  final List<String> _noteTypes = [
    'Progress Note',
    'Consultation Note',
    'Discharge Summary',
    'Emergency Note',
    'Follow-up Note',
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _notesController = TextEditingController();
    _treatmentController = TextEditingController();
    _bpController = TextEditingController();
    _hrController = TextEditingController();
    _tempController = TextEditingController();
    _respController = TextEditingController();
    _oxygenController = TextEditingController();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _notesController.dispose();
    _treatmentController.dispose();
    _bpController.dispose();
    _hrController.dispose();
    _tempController.dispose();
    _respController.dispose();
    _oxygenController.dispose();
    super.dispose();
  }

  void _onVoiceTextReceived(String text) {
    setState(() {
      _notesController.text = text;
      _showVoiceInput = false;
    });
  }

  void _saveDocumentation() {
    final documentation = {
      'type': _selectedNoteType,
      'notes': _notesController.text,
      'treatment': _treatmentController.text,
      'vitals': {
        'bloodPressure': _bpController.text,
        'heartRate': _hrController.text,
        'temperature': _tempController.text,
        'respiratory': _respController.text,
        'oxygenSaturation': _oxygenController.text,
      },
      'isEmergency': _isEmergency,
      'timestamp': DateTime.now(),
    };

    widget.onDocumentationSaved(documentation);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 85.h,
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Header
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.2),
                ),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Quick Documentation',
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                ),
                Row(
                  children: [
                    IconButton(
                      onPressed: () {
                        setState(() {
                          _showVoiceInput = !_showVoiceInput;
                        });
                      },
                      icon: CustomIconWidget(
                        iconName: 'mic',
                        size: 24,
                        color: _showVoiceInput
                            ? AppTheme.lightTheme.colorScheme.primary
                            : AppTheme.lightTheme.colorScheme.secondary,
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(context),
                      icon: CustomIconWidget(
                        iconName: 'close',
                        size: 24,
                        color: AppTheme.lightTheme.colorScheme.secondary,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Voice Input Widget
          if (_showVoiceInput) ...[
            Container(
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.primaryContainer
                    .withValues(alpha: 0.1),
                border: Border(
                  bottom: BorderSide(
                    color: AppTheme.lightTheme.colorScheme.outline
                        .withValues(alpha: 0.2),
                  ),
                ),
              ),
              child: VoiceToTextWidget(
                onTextReceived: _onVoiceTextReceived,
              ),
            ),
          ],

          // Tab Bar
          Container(
            margin: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.2),
              ),
            ),
            child: TabBar(
              controller: _tabController,
              tabs: const [
                Tab(text: 'Notes'),
                Tab(text: 'Vitals'),
                Tab(text: 'Treatment'),
              ],
              labelColor: AppTheme.lightTheme.colorScheme.primary,
              unselectedLabelColor: AppTheme.lightTheme.colorScheme.secondary,
              indicatorColor: AppTheme.lightTheme.colorScheme.primary,
              dividerColor: Colors.transparent,
            ),
          ),

          // Tab Content
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                // Notes Tab
                _buildNotesTab(),
                // Vitals Tab
                _buildVitalsTab(),
                // Treatment Tab
                _buildTreatmentTab(),
              ],
            ),
          ),

          // Bottom Actions
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              border: Border(
                top: BorderSide(
                  color: AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.2),
                ),
              ),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    Checkbox(
                      value: _isEmergency,
                      onChanged: (value) {
                        setState(() {
                          _isEmergency = value ?? false;
                        });
                      },
                    ),
                    Text(
                      'Mark as Emergency Note',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: _isEmergency
                                ? AppTheme.lightTheme.colorScheme.error
                                : AppTheme.lightTheme.colorScheme.onSurface,
                            fontWeight: _isEmergency
                                ? FontWeight.w600
                                : FontWeight.w400,
                          ),
                    ),
                  ],
                ),
                SizedBox(height: 2.h),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Cancel'),
                      ),
                    ),
                    SizedBox(width: 4.w),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _saveDocumentation,
                        style: _isEmergency
                            ? ElevatedButton.styleFrom(
                                backgroundColor:
                                    AppTheme.lightTheme.colorScheme.error,
                              )
                            : null,
                        child: Text(_isEmergency
                            ? 'Save Emergency Note'
                            : 'Save Documentation'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNotesTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Note Type',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 1.h),
          DropdownButtonFormField<String>(
            value: _selectedNoteType,
            decoration: const InputDecoration(
              contentPadding:
                  EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
            items: _noteTypes.map((type) {
              return DropdownMenuItem(
                value: type,
                child: Text(type),
              );
            }).toList(),
            onChanged: (value) {
              setState(() {
                _selectedNoteType = value ?? 'Progress Note';
              });
            },
          ),
          SizedBox(height: 3.h),
          Text(
            'Clinical Notes',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 1.h),
          TextField(
            controller: _notesController,
            maxLines: 8,
            decoration: const InputDecoration(
              hintText:
                  'Enter clinical observations, symptoms, and findings...',
              alignLabelWithHint: true,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVitalsTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Vital Signs',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _bpController,
                  decoration: const InputDecoration(
                    labelText: 'Blood Pressure',
                    hintText: '120/80',
                    suffixText: 'mmHg',
                  ),
                ),
              ),
              SizedBox(width: 4.w),
              Expanded(
                child: TextField(
                  controller: _hrController,
                  decoration: const InputDecoration(
                    labelText: 'Heart Rate',
                    hintText: '72',
                    suffixText: 'bpm',
                  ),
                  keyboardType: TextInputType.number,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _tempController,
                  decoration: const InputDecoration(
                    labelText: 'Temperature',
                    hintText: '37.0',
                    suffixText: '°C',
                  ),
                  keyboardType: TextInputType.number,
                ),
              ),
              SizedBox(width: 4.w),
              Expanded(
                child: TextField(
                  controller: _respController,
                  decoration: const InputDecoration(
                    labelText: 'Respiratory Rate',
                    hintText: '16',
                    suffixText: '/min',
                  ),
                  keyboardType: TextInputType.number,
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
          TextField(
            controller: _oxygenController,
            decoration: const InputDecoration(
              labelText: 'Oxygen Saturation',
              hintText: '98',
              suffixText: '%',
            ),
            keyboardType: TextInputType.number,
          ),
        ],
      ),
    );
  }

  Widget _buildTreatmentTab() {
    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Treatment Plan',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 2.h),
          TextField(
            controller: _treatmentController,
            maxLines: 8,
            decoration: const InputDecoration(
              hintText:
                  'Enter treatment plan, medications, procedures, and follow-up instructions...',
              alignLabelWithHint: true,
            ),
          ),
        ],
      ),
    );
  }
}
