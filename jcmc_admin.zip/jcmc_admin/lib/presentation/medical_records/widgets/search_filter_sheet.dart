import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';

class SearchFilterSheet extends StatefulWidget {
  final Function(Map<String, dynamic>) onFiltersApplied;
  final Map<String, dynamic> currentFilters;

  const SearchFilterSheet({
    Key? key,
    required this.onFiltersApplied,
    required this.currentFilters,
  }) : super(key: key);

  @override
  State<SearchFilterSheet> createState() => _SearchFilterSheetState();
}

class _SearchFilterSheetState extends State<SearchFilterSheet> {
  late TextEditingController _searchController;
  late DateTime _startDate;
  late DateTime _endDate;
  String _selectedPhysician = '';
  String _selectedCondition = '';
  String _selectedTreatment = '';

  final List<String> _physicians = [
    'All Physicians',
    'Dr. Sarah Johnson',
    'Dr. Michael Chen',
    'Dr. Emily Rodriguez',
    'Dr. David Kumar',
    'Dr. Lisa Thompson',
  ];

  final List<String> _conditions = [
    'All Conditions',
    'Hypertension',
    'Diabetes',
    'Respiratory Issues',
    'Cardiac Conditions',
    'Neurological',
    'Gastrointestinal',
  ];

  final List<String> _treatments = [
    'All Treatments',
    'Medication',
    'Surgery',
    'Physical Therapy',
    'Diagnostic Tests',
    'Follow-up Care',
  ];

  @override
  void initState() {
    super.initState();
    _searchController = TextEditingController(
      text: widget.currentFilters['searchQuery'] as String? ?? '',
    );
    _startDate = widget.currentFilters['startDate'] as DateTime? ??
        DateTime.now().subtract(const Duration(days: 30));
    _endDate = widget.currentFilters['endDate'] as DateTime? ?? DateTime.now();
    _selectedPhysician =
        widget.currentFilters['physician'] as String? ?? 'All Physicians';
    _selectedCondition =
        widget.currentFilters['condition'] as String? ?? 'All Conditions';
    _selectedTreatment =
        widget.currentFilters['treatment'] as String? ?? 'All Treatments';
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  String _formatDate(DateTime date) {
    return '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';
  }

  Future<void> _selectDateRange() async {
    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime.now().subtract(const Duration(days: 365 * 5)),
      lastDate: DateTime.now(),
      initialDateRange: DateTimeRange(start: _startDate, end: _endDate),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: Theme.of(context).colorScheme.copyWith(
                  primary: AppTheme.lightTheme.colorScheme.primary,
                ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        _startDate = picked.start;
        _endDate = picked.end;
      });
    }
  }

  void _applyFilters() {
    final filters = {
      'searchQuery': _searchController.text,
      'startDate': _startDate,
      'endDate': _endDate,
      'physician': _selectedPhysician,
      'condition': _selectedCondition,
      'treatment': _selectedTreatment,
    };
    widget.onFiltersApplied(filters);
    Navigator.pop(context);
  }

  void _clearFilters() {
    setState(() {
      _searchController.clear();
      _startDate = DateTime.now().subtract(const Duration(days: 30));
      _endDate = DateTime.now();
      _selectedPhysician = 'All Physicians';
      _selectedCondition = 'All Conditions';
      _selectedTreatment = 'All Treatments';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Search & Filter Records',
                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
              ),
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: CustomIconWidget(
                  iconName: 'close',
                  size: 24,
                  color: AppTheme.lightTheme.colorScheme.secondary,
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),

          // Search Field
          TextField(
            controller: _searchController,
            decoration: InputDecoration(
              labelText: 'Search medical records',
              hintText: 'Enter keywords, symptoms, or notes...',
              prefixIcon: Padding(
                padding: EdgeInsets.all(3.w),
                child: CustomIconWidget(
                  iconName: 'search',
                  size: 20,
                  color: AppTheme.lightTheme.colorScheme.secondary,
                ),
              ),
            ),
          ),
          SizedBox(height: 3.h),

          // Date Range
          Text(
            'Date Range',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 1.h),
          InkWell(
            onTap: _selectDateRange,
            borderRadius: BorderRadius.circular(8),
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              decoration: BoxDecoration(
                border: Border.all(
                  color: AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.3),
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  CustomIconWidget(
                    iconName: 'date_range',
                    size: 20,
                    color: AppTheme.lightTheme.colorScheme.primary,
                  ),
                  SizedBox(width: 3.w),
                  Text(
                    '${_formatDate(_startDate)} - ${_formatDate(_endDate)}',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const Spacer(),
                  CustomIconWidget(
                    iconName: 'keyboard_arrow_down',
                    size: 20,
                    color: AppTheme.lightTheme.colorScheme.secondary,
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 3.h),

          // Physician Filter
          Text(
            'Attending Physician',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 1.h),
          DropdownButtonFormField<String>(
            value: _selectedPhysician,
            decoration: const InputDecoration(
              contentPadding:
                  EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
            items: _physicians.map((physician) {
              return DropdownMenuItem(
                value: physician,
                child: Text(physician),
              );
            }).toList(),
            onChanged: (value) {
              setState(() {
                _selectedPhysician = value ?? 'All Physicians';
              });
            },
          ),
          SizedBox(height: 3.h),

          // Condition Filter
          Text(
            'Medical Condition',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 1.h),
          DropdownButtonFormField<String>(
            value: _selectedCondition,
            decoration: const InputDecoration(
              contentPadding:
                  EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
            items: _conditions.map((condition) {
              return DropdownMenuItem(
                value: condition,
                child: Text(condition),
              );
            }).toList(),
            onChanged: (value) {
              setState(() {
                _selectedCondition = value ?? 'All Conditions';
              });
            },
          ),
          SizedBox(height: 3.h),

          // Treatment Filter
          Text(
            'Treatment Type',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
          ),
          SizedBox(height: 1.h),
          DropdownButtonFormField<String>(
            value: _selectedTreatment,
            decoration: const InputDecoration(
              contentPadding:
                  EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
            items: _treatments.map((treatment) {
              return DropdownMenuItem(
                value: treatment,
                child: Text(treatment),
              );
            }).toList(),
            onChanged: (value) {
              setState(() {
                _selectedTreatment = value ?? 'All Treatments';
              });
            },
          ),
          SizedBox(height: 4.h),

          // Action Buttons
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: _clearFilters,
                  child: const Text('Clear All'),
                ),
              ),
              SizedBox(width: 4.w),
              Expanded(
                child: ElevatedButton(
                  onPressed: _applyFilters,
                  child: const Text('Apply Filters'),
                ),
              ),
            ],
          ),
          SizedBox(height: 2.h),
        ],
      ),
    );
  }
}
