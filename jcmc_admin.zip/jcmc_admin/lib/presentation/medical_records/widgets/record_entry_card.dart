import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';

class RecordEntryCard extends StatelessWidget {
  final Map<String, dynamic> record;
  final VoidCallback? onTap;
  final VoidCallback? onFlag;
  final VoidCallback? onShare;
  final VoidCallback? onPrint;
  final VoidCallback? onArchive;
  final bool isExpanded;

  const RecordEntryCard({
    Key? key,
    required this.record,
    this.onTap,
    this.onFlag,
    this.onShare,
    this.onPrint,
    this.onArchive,
    this.isExpanded = false,
  }) : super(key: key);

  Color _getStatusColor() {
    final status = (record['status'] as String? ?? '').toLowerCase();
    switch (status) {
      case 'critical':
        return AppTheme.lightTheme.colorScheme.error;
      case 'abnormal':
        return AppTheme.lightTheme.colorScheme.tertiary.withValues(alpha: 0.8);
      case 'normal':
        return AppTheme.lightTheme.colorScheme.tertiary;
      default:
        return AppTheme.lightTheme.colorScheme.secondary;
    }
  }

  @override
  Widget build(BuildContext context) {
    final date = record['date'] as String? ?? '';
    final physician = record['physician'] as String? ?? '';
    final summary = record['summary'] as String? ?? '';
    final fullText = record['fullText'] as String? ?? '';
    final vitals = record['vitals'] as Map<String, dynamic>? ?? {};
    final treatment = record['treatment'] as String? ?? '';

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: EdgeInsets.all(4.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 1.w,
                    height: 6.h,
                    decoration: BoxDecoration(
                      color: _getStatusColor(),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              date,
                              style: Theme.of(context)
                                  .textTheme
                                  .titleMedium
                                  ?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                            ),
                            PopupMenuButton<String>(
                              onSelected: (value) {
                                switch (value) {
                                  case 'flag':
                                    onFlag?.call();
                                    break;
                                  case 'share':
                                    onShare?.call();
                                    break;
                                  case 'print':
                                    onPrint?.call();
                                    break;
                                  case 'archive':
                                    onArchive?.call();
                                    break;
                                }
                              },
                              itemBuilder: (context) => [
                                PopupMenuItem(
                                  value: 'flag',
                                  child: Row(
                                    children: [
                                      CustomIconWidget(
                                        iconName: 'flag',
                                        size: 20,
                                        color: AppTheme
                                            .lightTheme.colorScheme.secondary,
                                      ),
                                      SizedBox(width: 2.w),
                                      Text('Flag for Review'),
                                    ],
                                  ),
                                ),
                                PopupMenuItem(
                                  value: 'share',
                                  child: Row(
                                    children: [
                                      CustomIconWidget(
                                        iconName: 'share',
                                        size: 20,
                                        color: AppTheme
                                            .lightTheme.colorScheme.secondary,
                                      ),
                                      SizedBox(width: 2.w),
                                      Text('Share with Physician'),
                                    ],
                                  ),
                                ),
                                PopupMenuItem(
                                  value: 'print',
                                  child: Row(
                                    children: [
                                      CustomIconWidget(
                                        iconName: 'print',
                                        size: 20,
                                        color: AppTheme
                                            .lightTheme.colorScheme.secondary,
                                      ),
                                      SizedBox(width: 2.w),
                                      Text('Print Summary'),
                                    ],
                                  ),
                                ),
                                PopupMenuItem(
                                  value: 'archive',
                                  child: Row(
                                    children: [
                                      CustomIconWidget(
                                        iconName: 'archive',
                                        size: 20,
                                        color: AppTheme
                                            .lightTheme.colorScheme.secondary,
                                      ),
                                      SizedBox(width: 2.w),
                                      Text('Archive Entry'),
                                    ],
                                  ),
                                ),
                              ],
                              child: CustomIconWidget(
                                iconName: 'more_vert',
                                size: 20,
                                color:
                                    AppTheme.lightTheme.colorScheme.secondary,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 0.5.h),
                        Text(
                          'Dr. $physician',
                          style: Theme.of(context)
                              .textTheme
                              .bodyMedium
                              ?.copyWith(
                                color: AppTheme.lightTheme.colorScheme.primary,
                                fontWeight: FontWeight.w500,
                              ),
                        ),
                        SizedBox(height: 1.h),
                        Text(
                          summary,
                          style: Theme.of(context).textTheme.bodyMedium,
                          maxLines: isExpanded ? null : 2,
                          overflow: isExpanded ? null : TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              if (isExpanded) ...[
                SizedBox(height: 2.h),
                Divider(
                    color: AppTheme.lightTheme.colorScheme.outline
                        .withValues(alpha: 0.3)),
                SizedBox(height: 1.h),
                if (fullText.isNotEmpty) ...[
                  Text(
                    'Full Documentation',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  SizedBox(height: 1.h),
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.all(3.w),
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.colorScheme.surface,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: AppTheme.lightTheme.colorScheme.outline
                            .withValues(alpha: 0.2),
                      ),
                    ),
                    child: Text(
                      fullText,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ),
                  SizedBox(height: 2.h),
                ],
                if (vitals.isNotEmpty) ...[
                  Text(
                    'Vital Signs',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  SizedBox(height: 1.h),
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.all(3.w),
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.colorScheme.primaryContainer
                          .withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: AppTheme.lightTheme.colorScheme.primary
                            .withValues(alpha: 0.2),
                      ),
                    ),
                    child: Wrap(
                      spacing: 4.w,
                      runSpacing: 1.h,
                      children: vitals.entries.map((entry) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              entry.key,
                              style: Theme.of(context)
                                  .textTheme
                                  .bodySmall
                                  ?.copyWith(
                                    color: AppTheme
                                        .lightTheme.colorScheme.secondary,
                                    fontWeight: FontWeight.w500,
                                  ),
                            ),
                            Text(
                              entry.value.toString(),
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyMedium
                                  ?.copyWith(
                                    fontWeight: FontWeight.w600,
                                  ),
                            ),
                          ],
                        );
                      }).toList(),
                    ),
                  ),
                  SizedBox(height: 2.h),
                ],
                if (treatment.isNotEmpty) ...[
                  Text(
                    'Treatment Plan',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                  SizedBox(height: 1.h),
                  Container(
                    width: double.infinity,
                    padding: EdgeInsets.all(3.w),
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.colorScheme.tertiaryContainer
                          .withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: AppTheme.lightTheme.colorScheme.tertiary
                            .withValues(alpha: 0.2),
                      ),
                    ),
                    child: Text(
                      treatment,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ),
                ],
              ],
              if (!isExpanded) ...[
                SizedBox(height: 1.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    CustomIconWidget(
                      iconName: 'expand_more',
                      size: 20,
                      color: AppTheme.lightTheme.colorScheme.secondary,
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
