import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';

class VoiceToTextWidget extends StatefulWidget {
  final Function(String) onTextReceived;
  final VoidCallback? onRecordingStart;
  final VoidCallback? onRecordingStop;

  const VoiceToTextWidget({
    Key? key,
    required this.onTextReceived,
    this.onRecordingStart,
    this.onRecordingStop,
  }) : super(key: key);

  @override
  State<VoiceToTextWidget> createState() => _VoiceToTextWidgetState();
}

class _VoiceToTextWidgetState extends State<VoiceToTextWidget>
    with TickerProviderStateMixin {
  final AudioRecorder _audioRecorder = AudioRecorder();
  bool _isRecording = false;
  bool _isProcessing = false;
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 1.2,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _animationController.dispose();
    _audioRecorder.dispose();
    super.dispose();
  }

  Future<bool> _requestMicrophonePermission() async {
    if (kIsWeb) return true;

    final status = await Permission.microphone.request();
    return status.isGranted;
  }

  Future<void> _startRecording() async {
    try {
      if (!await _requestMicrophonePermission()) {
        _showPermissionDeniedMessage();
        return;
      }

      if (await _audioRecorder.hasPermission()) {
        setState(() {
          _isRecording = true;
        });

        _animationController.repeat(reverse: true);
        widget.onRecordingStart?.call();

        if (kIsWeb) {
          await _audioRecorder.start(
            const RecordConfig(encoder: AudioEncoder.wav),
            path: 'medical_note_recording.wav',
          );
        } else {
          await _audioRecorder.start(
            const RecordConfig(encoder: AudioEncoder.aacLc),
            path: 'medical_note_recording.aac',
          );
        }
      }
    } catch (e) {
      setState(() {
        _isRecording = false;
      });
      _animationController.stop();
      _showErrorMessage('Failed to start recording. Please try again.');
    }
  }

  Future<void> _stopRecording() async {
    try {
      setState(() {
        _isRecording = false;
        _isProcessing = true;
      });

      _animationController.stop();
      _animationController.reset();
      widget.onRecordingStop?.call();

      final path = await _audioRecorder.stop();

      if (path != null) {
        // Simulate voice-to-text processing with medical terminology
        await Future.delayed(const Duration(seconds: 2));

        final medicalTexts = [
          'Patient presents with acute abdominal pain in the right lower quadrant. Vital signs stable. Temperature 37.2°C, BP 120/80, HR 88 bpm. Recommended CT scan to rule out appendicitis.',
          'Follow-up examination shows significant improvement in respiratory symptoms. Chest clear on auscultation. Patient reports decreased cough and improved sleep quality. Continue current medication regimen.',
          'Blood pressure remains elevated at 150/95 despite current antihypertensive therapy. Patient counseled on dietary modifications and exercise. Consider adjusting medication dosage at next visit.',
          'Wound healing progressing well post-surgery. No signs of infection. Sutures intact. Patient advised to continue wound care protocol and return in one week for suture removal.',
          'Laboratory results show elevated glucose levels at 180 mg/dL. HbA1c at 8.2%. Discussed diabetes management plan with patient. Referred to endocrinologist for specialized care.',
        ];

        final randomText =
            medicalTexts[DateTime.now().millisecond % medicalTexts.length];
        widget.onTextReceived(randomText);
      }
    } catch (e) {
      _showErrorMessage('Failed to process recording. Please try again.');
    } finally {
      setState(() {
        _isProcessing = false;
      });
    }
  }

  void _showPermissionDeniedMessage() {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content:
            const Text('Microphone permission is required for voice recording'),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        action: SnackBarAction(
          label: 'Settings',
          textColor: Colors.white,
          onPressed: () => openAppSettings(),
        ),
      ),
    );
  }

  void _showErrorMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(4.w),
      child: Column(
        children: [
          AnimatedBuilder(
            animation: _scaleAnimation,
            builder: (context, child) {
              return Transform.scale(
                scale: _isRecording ? _scaleAnimation.value : 1.0,
                child: GestureDetector(
                  onTap: _isProcessing
                      ? null
                      : (_isRecording ? _stopRecording : _startRecording),
                  child: Container(
                    width: 16.w,
                    height: 16.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _isRecording
                          ? AppTheme.lightTheme.colorScheme.error
                          : AppTheme.lightTheme.colorScheme.primary,
                      boxShadow: [
                        BoxShadow(
                          color: (_isRecording
                                  ? AppTheme.lightTheme.colorScheme.error
                                  : AppTheme.lightTheme.colorScheme.primary)
                              .withValues(alpha: 0.3),
                          blurRadius: _isRecording ? 20 : 8,
                          spreadRadius: _isRecording ? 5 : 0,
                        ),
                      ],
                    ),
                    child: _isProcessing
                        ? SizedBox(
                            width: 6.w,
                            height: 6.w,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              valueColor:
                                  AlwaysStoppedAnimation<Color>(Colors.white),
                            ),
                          )
                        : CustomIconWidget(
                            iconName: _isRecording ? 'stop' : 'mic',
                            size: 8.w,
                            color: Colors.white,
                          ),
                  ),
                ),
              );
            },
          ),
          SizedBox(height: 2.h),
          Text(
            _isProcessing
                ? 'Processing voice...'
                : _isRecording
                    ? 'Recording... Tap to stop'
                    : 'Tap to start voice recording',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.secondary,
                  fontWeight: FontWeight.w500,
                ),
            textAlign: TextAlign.center,
          ),
          if (_isRecording) ...[
            SizedBox(height: 2.h),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.errorContainer
                    .withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: AppTheme.lightTheme.colorScheme.error
                      .withValues(alpha: 0.3),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 2.w,
                    height: 2.w,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppTheme.lightTheme.colorScheme.error,
                    ),
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Recording in progress',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: AppTheme.lightTheme.colorScheme.error,
                          fontWeight: FontWeight.w500,
                        ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}