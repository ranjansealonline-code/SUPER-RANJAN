import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/appointments_widget.dart';
import './widgets/billing_widget.dart';
import './widgets/medical_history_widget.dart';
import './widgets/patient_header_widget.dart';
import './widgets/patient_overview_widget.dart';

class PatientProfile extends StatefulWidget {
  const PatientProfile({Key? key}) : super(key: key);

  @override
  State<PatientProfile> createState() => _PatientProfileState();
}

class _PatientProfileState extends State<PatientProfile>
    with TickerProviderStateMixin {
  late TabController _tabController;

  // Mock patient data
  final Map<String, dynamic> patientData = {
    "patientId": "JCMC-2024-001234",
    "fullName": "Priya Sharma",
    "age": "34",
    "roomNumber": "A-205",
    "photo":
        "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    "admissionDate": "15/08/2024",
    "attendingPhysician": "Dr. Rajesh Kumar",
    "department": "Cardiology",
    "insuranceProvider": "Star Health Insurance",
    "policyNumber": "SH-2024-789456",
    "coverageType": "Premium Care",
    "approvalStatus": "Approved",
    "medicalAlerts": [
      {"type": "allergy", "message": "Penicillin Allergy"},
      {"type": "condition", "message": "Hypertension"},
      {"type": "critical", "message": "High Risk Patient"}
    ],
    "emergencyContacts": [
      {
        "name": "Amit Sharma",
        "relationship": "Husband",
        "phone": "+91 98765 43210"
      },
      {
        "name": "Sunita Sharma",
        "relationship": "Mother",
        "phone": "+91 87654 32109"
      }
    ],
    "vitalSigns": {
      "bloodPressure": "140/90 mmHg",
      "heartRate": "78 bpm",
      "temperature": "98.6°F",
      "oxygenSaturation": "98%",
      "timestamp": "Today, 10:30 AM"
    },
    "currentMedications": [
      {
        "name": "Amlodipine",
        "dosage": "5mg",
        "frequency": "Once daily",
        "prescribedBy": "Dr. Rajesh Kumar",
        "notes": "Take with food. Monitor blood pressure regularly."
      },
      {
        "name": "Metformin",
        "dosage": "500mg",
        "frequency": "Twice daily",
        "prescribedBy": "Dr. Rajesh Kumar",
        "notes": "Take before meals."
      },
      {
        "name": "Aspirin",
        "dosage": "75mg",
        "frequency": "Once daily",
        "prescribedBy": "Dr. Rajesh Kumar",
        "notes": "Blood thinner - take as prescribed."
      }
    ],
    "medicalHistory": [
      {
        "type": "diagnosis",
        "title": "Hypertension Diagnosis",
        "date": "10/08/2024",
        "description":
            "Patient diagnosed with stage 1 hypertension. Blood pressure consistently elevated above 140/90 mmHg.",
        "physician": "Dr. Rajesh Kumar"
      },
      {
        "type": "treatment",
        "title": "Cardiac Catheterization",
        "date": "05/08/2024",
        "description":
            "Diagnostic procedure to evaluate coronary arteries. Results showed mild narrowing in LAD.",
        "physician": "Dr. Rajesh Kumar"
      },
      {
        "type": "medication",
        "title": "Started Amlodipine",
        "date": "01/08/2024",
        "description":
            "Initiated antihypertensive medication to control blood pressure.",
        "physician": "Dr. Rajesh Kumar"
      },
      {
        "type": "procedure",
        "title": "ECG and Echocardiogram",
        "date": "28/07/2024",
        "description":
            "Cardiac evaluation showed normal heart rhythm with mild left ventricular hypertrophy.",
        "physician": "Dr. Rajesh Kumar"
      }
    ],
    "upcomingAppointments": [
      {
        "type": "Follow-up",
        "doctor": "Rajesh Kumar",
        "date": "25/08/2024",
        "time": "10:00 AM",
        "department": "Cardiology",
        "room": "C-301",
        "status": "confirmed",
        "notes": "Blood pressure monitoring and medication review."
      },
      {
        "type": "Consultation",
        "doctor": "Meera Patel",
        "date": "30/08/2024",
        "time": "2:30 PM",
        "department": "Endocrinology",
        "room": "E-205",
        "status": "scheduled",
        "notes": "Diabetes screening and consultation."
      }
    ],
    "pastAppointments": [
      {
        "type": "Consultation",
        "doctor": "Rajesh Kumar",
        "date": "15/08/2024",
        "time": "9:00 AM",
        "department": "Cardiology",
        "room": "C-301",
        "status": "completed",
        "notes": "Initial consultation for chest pain and hypertension."
      },
      {
        "type": "Procedure",
        "doctor": "Rajesh Kumar",
        "date": "05/08/2024",
        "time": "11:00 AM",
        "department": "Cardiology",
        "room": "C-401",
        "status": "completed",
        "notes": "Cardiac catheterization procedure completed successfully."
      }
    ],
    "billingInfo": {
      "totalAmount": "45,750.00",
      "amountPaid": "30,000.00",
      "outstandingBalance": "15,750.00",
      "paymentStatus": "partial",
      "insuranceCoverage": "25,000.00",
      "paymentMethod": "Insurance + Cash"
    },
    "invoices": [
      {
        "invoiceNumber": "INV-2024-001234",
        "date": "15/08/2024",
        "amount": "25,000.00",
        "services": [
          "Consultation Fee",
          "ECG",
          "Blood Tests",
          "Room Charges (3 days)"
        ]
      },
      {
        "invoiceNumber": "INV-2024-001235",
        "date": "05/08/2024",
        "amount": "20,750.00",
        "services": [
          "Cardiac Catheterization",
          "Procedure Room Charges",
          "Medications",
          "Monitoring Equipment"
        ]
      }
    ]
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        backgroundColor: AppTheme.lightTheme.appBarTheme.backgroundColor,
        elevation: AppTheme.lightTheme.appBarTheme.elevation,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: CustomIconWidget(
            iconName: 'arrow_back',
            color: AppTheme.lightTheme.colorScheme.onSurface,
            size: 6.w,
          ),
        ),
        title: Text(
          'Patient Profile',
          style: AppTheme.lightTheme.appBarTheme.titleTextStyle,
        ),
        actions: [
          PopupMenuButton<String>(
            icon: CustomIconWidget(
              iconName: 'more_vert',
              color: AppTheme.lightTheme.colorScheme.onSurface,
              size: 6.w,
            ),
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'edit',
                child: Text('Edit Profile'),
              ),
              const PopupMenuItem(
                value: 'medical_records',
                child: Text('View Medical Records'),
              ),
              const PopupMenuItem(
                value: 'discharge',
                child: Text('Discharge Summary'),
              ),
              const PopupMenuItem(
                value: 'transfer',
                child: Text('Transfer Patient'),
              ),
            ],
            onSelected: (value) {
              switch (value) {
                case 'medical_records':
                  Navigator.pushNamed(context, '/medical-records');
                  break;
                case 'edit':
                  _showEditDialog();
                  break;
                case 'discharge':
                  _showDischargeDialog();
                  break;
                case 'transfer':
                  _showTransferDialog();
                  break;
              }
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Patient Header
          Container(
            padding: EdgeInsets.all(4.w),
            child: PatientHeaderWidget(
              patientData: patientData,
              onEmergencyCall: _handleEmergencyCall,
            ),
          ),

          // Tab Bar
          Container(
            margin: EdgeInsets.symmetric(horizontal: 4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(2.w),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.2),
                width: 1,
              ),
            ),
            child: TabBar(
              controller: _tabController,
              labelColor: AppTheme.lightTheme.tabBarTheme.labelColor,
              unselectedLabelColor:
                  AppTheme.lightTheme.tabBarTheme.unselectedLabelColor,
              indicatorColor: AppTheme.lightTheme.tabBarTheme.indicatorColor,
              indicatorSize: TabBarIndicatorSize.tab,
              labelStyle: AppTheme.lightTheme.tabBarTheme.labelStyle,
              unselectedLabelStyle:
                  AppTheme.lightTheme.tabBarTheme.unselectedLabelStyle,
              tabs: const [
                Tab(text: 'Overview'),
                Tab(text: 'History'),
                Tab(text: 'Appointments'),
                Tab(text: 'Billing'),
              ],
            ),
          ),

          // Tab Bar View
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                PatientOverviewWidget(
                  patientData: patientData,
                  onContactEmergency: _handleEmergencyCall,
                ),
                MedicalHistoryWidget(
                  patientData: patientData,
                ),
                AppointmentsWidget(
                  patientData: patientData,
                  onAppointmentTap: _handleAppointmentTap,
                ),
                BillingWidget(
                  patientData: patientData,
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showContextMenu,
        backgroundColor:
            AppTheme.lightTheme.floatingActionButtonTheme.backgroundColor,
        child: CustomIconWidget(
          iconName: 'add',
          color:
              AppTheme.lightTheme.floatingActionButtonTheme.foregroundColor ??
                  Colors.white,
          size: 6.w,
        ),
      ),
    );
  }

  void _handleEmergencyCall() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Emergency Call',
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Text(
          'Calling emergency contact: Amit Sharma\n+91 98765 43210',
          style: AppTheme.lightTheme.textTheme.bodyMedium,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // Simulate call
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Calling emergency contact...')),
              );
            },
            child: const Text('Call'),
          ),
        ],
      ),
    );
  }

  void _handleAppointmentTap(Map<String, dynamic> appointment) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Appointment Details',
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Type: ${appointment['type']}'),
            Text('Doctor: Dr. ${appointment['doctor']}'),
            Text('Date: ${appointment['date']}'),
            Text('Time: ${appointment['time']}'),
            Text('Department: ${appointment['department']}'),
            Text('Room: ${appointment['room']}'),
            Text('Status: ${appointment['status']}'),
            if (appointment['notes'] != null)
              Text('Notes: ${appointment['notes']}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  void _showContextMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(4.w)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(4.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(0.25.h),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              'Quick Actions',
              style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            SizedBox(height: 3.h),
            _buildQuickActionItem('Add Note', 'note_add', () {
              Navigator.pop(context);
              _showAddNoteDialog();
            }),
            _buildQuickActionItem('Schedule Appointment', 'event', () {
              Navigator.pop(context);
              Navigator.pushNamed(context, '/appointment-scheduler');
            }),
            _buildQuickActionItem('Update Status', 'update', () {
              Navigator.pop(context);
              _showUpdateStatusDialog();
            }),
            _buildQuickActionItem('Contact Family', 'phone', () {
              Navigator.pop(context);
              _handleEmergencyCall();
            }),
            SizedBox(height: 2.h),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActionItem(
      String title, String iconName, VoidCallback onTap) {
    return ListTile(
      leading: Container(
        padding: EdgeInsets.all(2.w),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(2.w),
        ),
        child: CustomIconWidget(
          iconName: iconName,
          color: AppTheme.lightTheme.colorScheme.primary,
          size: 5.w,
        ),
      ),
      title: Text(
        title,
        style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
          fontWeight: FontWeight.w500,
        ),
      ),
      onTap: onTap,
    );
  }

  void _showAddNoteDialog() {
    final TextEditingController noteController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Add Note',
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        content: TextField(
          controller: noteController,
          maxLines: 4,
          decoration: const InputDecoration(
            hintText: 'Enter your note here...',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Note added successfully')),
              );
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
  }

  void _showUpdateStatusDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Update Patient Status',
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text('Stable'),
              leading: Radio<String>(
                value: 'stable',
                groupValue: 'stable',
                onChanged: (value) {},
              ),
            ),
            ListTile(
              title: const Text('Critical'),
              leading: Radio<String>(
                value: 'critical',
                groupValue: 'stable',
                onChanged: (value) {},
              ),
            ),
            ListTile(
              title: const Text('Recovering'),
              leading: Radio<String>(
                value: 'recovering',
                groupValue: 'stable',
                onChanged: (value) {},
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Status updated successfully')),
              );
            },
            child: const Text('Update'),
          ),
        ],
      ),
    );
  }

  void _showEditDialog() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text('Edit functionality would be implemented here')),
    );
  }

  void _showDischargeDialog() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text(
              'Discharge summary functionality would be implemented here')),
    );
  }

  void _showTransferDialog() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content:
              Text('Patient transfer functionality would be implemented here')),
    );
  }
}
