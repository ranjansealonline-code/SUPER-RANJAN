import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';

class MedicalHistoryWidget extends StatelessWidget {
  final Map<String, dynamic> patientData;

  const MedicalHistoryWidget({
    Key? key,
    required this.patientData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final medicalHistory = patientData['medicalHistory'] as List? ?? [];

    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Current Medications Section
          _buildCurrentMedicationsSection(),
          SizedBox(height: 3.h),

          // Medical History Timeline
          Text(
            'Medical History Timeline',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: AppTheme.lightTheme.colorScheme.onSurface,
            ),
          ),
          SizedBox(height: 2.h),

          if (medicalHistory.isEmpty)
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface,
                borderRadius: BorderRadius.circular(3.w),
                border: Border.all(
                  color: AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.2),
                  width: 1,
                ),
              ),
              child: Text(
                'No medical history available',
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  fontStyle: FontStyle.italic,
                ),
                textAlign: TextAlign.center,
              ),
            )
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: medicalHistory.length,
              separatorBuilder: (context, index) => SizedBox(height: 2.h),
              itemBuilder: (context, index) {
                final historyItem =
                    medicalHistory[index] as Map<String, dynamic>;
                return _buildHistoryTimelineItem(historyItem, index == 0);
              },
            ),
        ],
      ),
    );
  }

  Widget _buildCurrentMedicationsSection() {
    final medications = patientData['currentMedications'] as List? ?? [];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Current Medications',
          style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
            fontWeight: FontWeight.w600,
            color: AppTheme.lightTheme.colorScheme.onSurface,
          ),
        ),
        SizedBox(height: 2.h),
        if (medications.isEmpty)
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface,
              borderRadius: BorderRadius.circular(3.w),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.2),
                width: 1,
              ),
            ),
            child: Text(
              'No current medications',
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                fontStyle: FontStyle.italic,
              ),
              textAlign: TextAlign.center,
            ),
          )
        else
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: medications.length,
            separatorBuilder: (context, index) => SizedBox(height: 2.h),
            itemBuilder: (context, index) {
              final medication = medications[index] as Map<String, dynamic>;
              return _buildMedicationCard(medication);
            },
          ),
      ],
    );
  }

  Widget _buildMedicationCard(Map<String, dynamic> medication) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(3.w),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      medication['name'] as String? ?? 'Unknown Medication',
                      style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: AppTheme.lightTheme.colorScheme.onSurface,
                      ),
                    ),
                    SizedBox(height: 1.h),
                    Text(
                      '${medication['dosage'] ?? 'N/A'} • ${medication['frequency'] ?? 'N/A'}',
                      style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      'Prescribed by: ${medication['prescribedBy'] ?? 'Unknown'}',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              PopupMenuButton<String>(
                icon: CustomIconWidget(
                  iconName: 'more_vert',
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  size: 5.w,
                ),
                itemBuilder: (context) => [
                  const PopupMenuItem(
                    value: 'administered',
                    child: Text('Mark Administered'),
                  ),
                  const PopupMenuItem(
                    value: 'reminder',
                    child: Text('Set Reminder'),
                  ),
                  const PopupMenuItem(
                    value: 'pharmacy',
                    child: Text('Contact Pharmacy'),
                  ),
                ],
                onSelected: (value) {
                  // Handle medication actions
                },
              ),
            ],
          ),
          if (medication['notes'] != null &&
              (medication['notes'] as String).isNotEmpty) ...[
            SizedBox(height: 2.h),
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(3.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.primaryContainer
                    .withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(2.w),
              ),
              child: Text(
                medication['notes'] as String,
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildHistoryTimelineItem(
      Map<String, dynamic> historyItem, bool isLatest) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(3.w),
        border: Border.all(
          color: isLatest
              ? AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.3)
              : AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
          width: isLatest ? 2 : 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: EdgeInsets.all(2.w),
                decoration: BoxDecoration(
                  color:
                      _getHistoryTypeColor(historyItem['type'] as String? ?? '')
                          .withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(1.5.w),
                ),
                child: CustomIconWidget(
                  iconName:
                      _getHistoryTypeIcon(historyItem['type'] as String? ?? ''),
                  color: _getHistoryTypeColor(
                      historyItem['type'] as String? ?? ''),
                  size: 4.w,
                ),
              ),
              SizedBox(width: 3.w),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      historyItem['title'] as String? ?? 'Medical Event',
                      style: AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: AppTheme.lightTheme.colorScheme.onSurface,
                      ),
                    ),
                    SizedBox(height: 0.5.h),
                    Text(
                      historyItem['date'] as String? ?? 'Unknown date',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              if (isLatest)
                Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.primary
                        .withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(1.w),
                  ),
                  child: Text(
                    'Latest',
                    style: AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.primary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
            ],
          ),
          if (historyItem['description'] != null &&
              (historyItem['description'] as String).isNotEmpty) ...[
            SizedBox(height: 2.h),
            Text(
              historyItem['description'] as String,
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
              ),
            ),
          ],
          if (historyItem['physician'] != null) ...[
            SizedBox(height: 1.h),
            Text(
              'Physician: ${historyItem['physician']}',
              style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                fontWeight: FontWeight.w500,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Color _getHistoryTypeColor(String type) {
    switch (type.toLowerCase()) {
      case 'surgery':
      case 'procedure':
        return AppTheme.lightTheme.colorScheme.error;
      case 'treatment':
      case 'therapy':
        return AppTheme.lightTheme.colorScheme.primary;
      case 'diagnosis':
      case 'condition':
        return const Color(0xFFD97706);
      case 'medication':
        return const Color(0xFF059669);
      default:
        return AppTheme.lightTheme.colorScheme.secondary;
    }
  }

  String _getHistoryTypeIcon(String type) {
    switch (type.toLowerCase()) {
      case 'surgery':
      case 'procedure':
        return 'medical_services';
      case 'treatment':
      case 'therapy':
        return 'healing';
      case 'diagnosis':
      case 'condition':
        return 'assignment';
      case 'medication':
        return 'medication';
      default:
        return 'event_note';
    }
  }
}
