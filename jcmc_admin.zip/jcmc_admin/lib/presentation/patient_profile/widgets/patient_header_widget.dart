import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';

class PatientHeaderWidget extends StatelessWidget {
  final Map<String, dynamic> patientData;
  final VoidCallback? onEmergencyCall;

  const PatientHeaderWidget({
    Key? key,
    required this.patientData,
    this.onEmergencyCall,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(3.w),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              // Patient Photo
              Container(
                width: 20.w,
                height: 20.w,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(2.w),
                  border: Border.all(
                    color: AppTheme.lightTheme.colorScheme.outline
                        .withValues(alpha: 0.3),
                    width: 2,
                  ),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(2.w),
                  child: CustomImageWidget(
                    imageUrl: patientData['photo'] as String? ?? '',
                    width: 20.w,
                    height: 20.w,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              SizedBox(width: 4.w),
              // Patient Info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      patientData['fullName'] as String? ?? 'Unknown Patient',
                      style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: AppTheme.lightTheme.colorScheme.onSurface,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    SizedBox(height: 1.h),
                    Row(
                      children: [
                        Text(
                          'Age: ${patientData['age'] ?? 'N/A'}',
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                        SizedBox(width: 4.w),
                        Container(
                          width: 1,
                          height: 3.h,
                          color: AppTheme.lightTheme.colorScheme.outline
                              .withValues(alpha: 0.3),
                        ),
                        SizedBox(width: 4.w),
                        Text(
                          'Room: ${patientData['roomNumber'] ?? 'N/A'}',
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: AppTheme
                                .lightTheme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              // Emergency Call Button
              GestureDetector(
                onTap: onEmergencyCall,
                child: Container(
                  padding: EdgeInsets.all(3.w),
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.error
                        .withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(2.w),
                  ),
                  child: CustomIconWidget(
                    iconName: 'phone',
                    color: AppTheme.lightTheme.colorScheme.error,
                    size: 6.w,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: 3.h),
          // Medical Alerts
          if (patientData['medicalAlerts'] != null &&
              (patientData['medicalAlerts'] as List).isNotEmpty)
            Wrap(
              spacing: 2.w,
              runSpacing: 1.h,
              children:
                  (patientData['medicalAlerts'] as List).map<Widget>((alert) {
                final alertMap = alert as Map<String, dynamic>;
                return Container(
                  padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                  decoration: BoxDecoration(
                    color: _getAlertColor(alertMap['type'] as String? ?? 'info')
                        .withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(1.5.w),
                    border: Border.all(
                      color:
                          _getAlertColor(alertMap['type'] as String? ?? 'info'),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CustomIconWidget(
                        iconName: _getAlertIcon(
                            alertMap['type'] as String? ?? 'info'),
                        color: _getAlertColor(
                            alertMap['type'] as String? ?? 'info'),
                        size: 4.w,
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        alertMap['message'] as String? ?? '',
                        style:
                            AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                          color: _getAlertColor(
                              alertMap['type'] as String? ?? 'info'),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
        ],
      ),
    );
  }

  Color _getAlertColor(String type) {
    switch (type.toLowerCase()) {
      case 'critical':
      case 'allergy':
        return AppTheme.lightTheme.colorScheme.error;
      case 'warning':
      case 'dnr':
        return const Color(0xFFD97706);
      case 'condition':
        return AppTheme.lightTheme.colorScheme.primary;
      default:
        return AppTheme.lightTheme.colorScheme.secondary;
    }
  }

  String _getAlertIcon(String type) {
    switch (type.toLowerCase()) {
      case 'critical':
        return 'warning';
      case 'allergy':
        return 'local_hospital';
      case 'dnr':
        return 'do_not_disturb';
      case 'condition':
        return 'medical_services';
      default:
        return 'info';
    }
  }
}
