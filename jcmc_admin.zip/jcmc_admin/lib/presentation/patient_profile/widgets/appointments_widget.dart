import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../../core/app_export.dart';
import '../../../theme/app_theme.dart';
import '../../../widgets/custom_icon_widget.dart';

class AppointmentsWidget extends StatelessWidget {
  final Map<String, dynamic> patientData;
  final Function(Map<String, dynamic>)? onAppointmentTap;

  const AppointmentsWidget({
    Key? key,
    required this.patientData,
    this.onAppointmentTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final upcomingAppointments =
        patientData['upcomingAppointments'] as List? ?? [];
    final pastAppointments = patientData['pastAppointments'] as List? ?? [];

    return SingleChildScrollView(
      padding: EdgeInsets.all(4.w),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Upcoming Appointments Section
          _buildAppointmentsSection(
            title: 'Upcoming Appointments',
            appointments: upcomingAppointments,
            isUpcoming: true,
          ),
          SizedBox(height: 3.h),

          // Past Appointments Section
          _buildAppointmentsSection(
            title: 'Past Appointments',
            appointments: pastAppointments,
            isUpcoming: false,
          ),
        ],
      ),
    );
  }

  Widget _buildAppointmentsSection({
    required String title,
    required List appointments,
    required bool isUpcoming,
  }) {
    return Builder(
      builder: (context) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                title,
                style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                ),
              ),
              if (isUpcoming)
                TextButton(
                  onPressed: () {
                    Navigator.pushNamed(context, '/appointment-scheduler');
                  },
                  child: Text(
                    'Schedule New',
                    style: AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.primary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
            ],
          ),
          SizedBox(height: 2.h),
          if (appointments.isEmpty)
            Container(
              width: double.infinity,
              padding: EdgeInsets.all(4.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface,
                borderRadius: BorderRadius.circular(3.w),
                border: Border.all(
                  color: AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.2),
                  width: 1,
                ),
              ),
              child: Text(
                isUpcoming ? 'No upcoming appointments' : 'No past appointments',
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  fontStyle: FontStyle.italic,
                ),
                textAlign: TextAlign.center,
              ),
            )
          else
            ListView.separated(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: appointments.length,
              separatorBuilder: (context, index) => SizedBox(height: 2.h),
              itemBuilder: (context, index) {
                final appointment = appointments[index] as Map<String, dynamic>;
                return _buildAppointmentCard(appointment, isUpcoming);
              },
            ),
        ],
      ),
    );
  }

  Widget _buildAppointmentCard(
      Map<String, dynamic> appointment, bool isUpcoming) {
    final status = appointment['status'] as String? ?? 'scheduled';

    return GestureDetector(
      onTap: () => onAppointmentTap?.call(appointment),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.all(4.w),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.circular(3.w),
          border: Border.all(
            color: _getStatusColor(status).withValues(alpha: 0.3),
            width: 1.5,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                // Appointment Type Icon
                Container(
                  padding: EdgeInsets.all(2.w),
                  decoration: BoxDecoration(
                    color: _getAppointmentTypeColor(
                            appointment['type'] as String? ?? '')
                        .withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(1.5.w),
                  ),
                  child: CustomIconWidget(
                    iconName: _getAppointmentTypeIcon(
                        appointment['type'] as String? ?? ''),
                    color: _getAppointmentTypeColor(
                        appointment['type'] as String? ?? ''),
                    size: 4.w,
                  ),
                ),
                SizedBox(width: 3.w),

                // Appointment Details
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        appointment['type'] as String? ??
                            'General Consultation',
                        style:
                            AppTheme.lightTheme.textTheme.titleSmall?.copyWith(
                          fontWeight: FontWeight.w600,
                          color: AppTheme.lightTheme.colorScheme.onSurface,
                        ),
                      ),
                      SizedBox(height: 0.5.h),
                      Text(
                        'Dr. ${appointment['doctor'] ?? 'Unknown'}',
                        style:
                            AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                          color:
                              AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),

                // Status Badge
                Container(
                  padding:
                      EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                  decoration: BoxDecoration(
                    color: _getStatusColor(status).withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(1.w),
                  ),
                  child: Text(
                    status.toUpperCase(),
                    style: AppTheme.lightTheme.textTheme.labelSmall?.copyWith(
                      color: _getStatusColor(status),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: 2.h),

            // Date and Time
            Row(
              children: [
                CustomIconWidget(
                  iconName: 'calendar_today',
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  size: 4.w,
                ),
                SizedBox(width: 2.w),
                Text(
                  appointment['date'] as String? ?? 'Unknown date',
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                ),
                SizedBox(width: 4.w),
                CustomIconWidget(
                  iconName: 'access_time',
                  color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  size: 4.w,
                ),
                SizedBox(width: 2.w),
                Text(
                  appointment['time'] as String? ?? 'Unknown time',
                  style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),

            // Department and Room
            if (appointment['department'] != null ||
                appointment['room'] != null) ...[
              SizedBox(height: 1.h),
              Row(
                children: [
                  if (appointment['department'] != null) ...[
                    CustomIconWidget(
                      iconName: 'business',
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      size: 4.w,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      appointment['department'] as String,
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                  if (appointment['department'] != null &&
                      appointment['room'] != null)
                    SizedBox(width: 4.w),
                  if (appointment['room'] != null) ...[
                    CustomIconWidget(
                      iconName: 'room',
                      color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      size: 4.w,
                    ),
                    SizedBox(width: 2.w),
                    Text(
                      'Room ${appointment['room']}',
                      style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                        color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ],
              ),
            ],

            // Notes
            if (appointment['notes'] != null &&
                (appointment['notes'] as String).isNotEmpty) ...[
              SizedBox(height: 2.h),
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(3.w),
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.primaryContainer
                      .withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(2.w),
                ),
                child: Text(
                  appointment['notes'] as String,
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ),
            ],

            // Action Buttons for Upcoming Appointments
            if (isUpcoming && status == 'scheduled') ...[
              SizedBox(height: 2.h),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () {
                        // Handle reschedule
                      },
                      style: OutlinedButton.styleFrom(
                        padding: EdgeInsets.symmetric(vertical: 2.h),
                      ),
                      child: Text(
                        'Reschedule',
                        style: AppTheme.lightTheme.textTheme.labelMedium,
                      ),
                    ),
                  ),
                  SizedBox(width: 3.w),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        // Handle cancel
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppTheme.lightTheme.colorScheme.error,
                        padding: EdgeInsets.symmetric(vertical: 2.h),
                      ),
                      child: Text(
                        'Cancel',
                        style:
                            AppTheme.lightTheme.textTheme.labelMedium?.copyWith(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'confirmed':
        return const Color(0xFF059669);
      case 'scheduled':
        return AppTheme.lightTheme.colorScheme.primary;
      case 'completed':
        return const Color(0xFF059669);
      case 'cancelled':
        return AppTheme.lightTheme.colorScheme.error;
      case 'rescheduled':
        return const Color(0xFFD97706);
      default:
        return AppTheme.lightTheme.colorScheme.secondary;
    }
  }

  Color _getAppointmentTypeColor(String type) {
    switch (type.toLowerCase()) {
      case 'consultation':
      case 'general':
        return AppTheme.lightTheme.colorScheme.primary;
      case 'follow-up':
        return const Color(0xFF059669);
      case 'surgery':
      case 'procedure':
        return AppTheme.lightTheme.colorScheme.error;
      case 'therapy':
      case 'rehabilitation':
        return const Color(0xFFD97706);
      default:
        return AppTheme.lightTheme.colorScheme.secondary;
    }
  }

  String _getAppointmentTypeIcon(String type) {
    switch (type.toLowerCase()) {
      case 'consultation':
      case 'general':
        return 'person';
      case 'follow-up':
        return 'refresh';
      case 'surgery':
      case 'procedure':
        return 'medical_services';
      case 'therapy':
      case 'rehabilitation':
        return 'healing';
      default:
        return 'event';
    }
  }
}