import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/advanced_filter_bottom_sheet.dart';
import './widgets/empty_state_widget.dart';
import './widgets/patient_card_widget.dart';
import './widgets/recent_searches_widget.dart';
import './widgets/search_filter_chips_widget.dart';

class PatientSearch extends StatefulWidget {
  const PatientSearch({Key? key}) : super(key: key);

  @override
  State<PatientSearch> createState() => _PatientSearchState();
}

class _PatientSearchState extends State<PatientSearch>
    with TickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();

  List<Map<String, dynamic>> _allPatients = [];
  List<Map<String, dynamic>> _filteredPatients = [];
  List<String> _activeFilters = [];
  List<String> _recentSearches = [];
  Map<String, dynamic> _advancedFilters = {};

  bool _isLoading = false;
  bool _isSearching = false;
  String _searchQuery = '';

  // Camera related
  CameraController? _cameraController;
  List<CameraDescription>? _cameras;
  bool _isCameraInitialized = false;
  bool _showCamera = false;

  @override
  void initState() {
    super.initState();
    _initializeData();
    _loadRecentSearches();
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    _cameraController?.dispose();
    super.dispose();
  }

  void _initializeData() {
    setState(() {
      _isLoading = true;
    });

    // Mock patient data
    _allPatients = [
      {
        "id": 1,
        "patientId": "JCMC001234",
        "name": "Rajesh Kumar Singh",
        "age": 45,
        "phone": "+91 98765 43210",
        "roomNumber": "A-101",
        "bedNumber": "B-12",
        "admissionStatus": "Admitted",
        "department": "Cardiology",
        "insuranceType": "Government",
        "attendingPhysician": "Dr. Priya Sharma",
        "photo":
            "https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=400",
        "alerts": ["Diabetes", "Hypertension"],
        "admissionDate": DateTime.now().subtract(Duration(days: 3)),
        "lastVisit": DateTime.now().subtract(Duration(hours: 6)),
      },
      {
        "id": 2,
        "patientId": "JCMC001235",
        "name": "Meera Devi Borah",
        "age": 32,
        "phone": "+91 87654 32109",
        "roomNumber": "B-205",
        "bedNumber": "B-08",
        "admissionStatus": "Emergency",
        "department": "Emergency",
        "insuranceType": "Private",
        "attendingPhysician": "Dr. Amit Gogoi",
        "photo":
            "https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=400",
        "alerts": ["Allergic to Penicillin"],
        "admissionDate": DateTime.now().subtract(Duration(hours: 2)),
        "lastVisit": DateTime.now().subtract(Duration(minutes: 30)),
      },
      {
        "id": 3,
        "patientId": "JCMC001236",
        "name": "Anand Prasad Das",
        "age": 67,
        "phone": "+91 76543 21098",
        "roomNumber": null,
        "bedNumber": null,
        "admissionStatus": "Outpatient",
        "department": "Orthopedics",
        "insuranceType": "Self-Pay",
        "attendingPhysician": "Dr. Ravi Choudhury",
        "photo":
            "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400",
        "alerts": [],
        "admissionDate": null,
        "lastVisit": DateTime.now().subtract(Duration(days: 1)),
      },
      {
        "id": 4,
        "patientId": "JCMC001237",
        "name": "Sunita Kalita",
        "age": 28,
        "phone": "+91 65432 10987",
        "roomNumber": "C-301",
        "bedNumber": "B-15",
        "admissionStatus": "Admitted",
        "department": "Gynecology",
        "insuranceType": "Corporate",
        "attendingPhysician": "Dr. Kavita Devi",
        "photo":
            "https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=400",
        "alerts": ["Pregnancy - High Risk"],
        "admissionDate": DateTime.now().subtract(Duration(days: 1)),
        "lastVisit": DateTime.now().subtract(Duration(hours: 4)),
      },
      {
        "id": 5,
        "patientId": "JCMC001238",
        "name": "Bhupen Hazarika",
        "age": 55,
        "phone": "+91 54321 09876",
        "roomNumber": "D-102",
        "bedNumber": "B-03",
        "admissionStatus": "Discharged",
        "department": "General Medicine",
        "insuranceType": "Government",
        "attendingPhysician": "Dr. Manash Pratim Sarma",
        "photo":
            "https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=400",
        "alerts": [],
        "admissionDate": DateTime.now().subtract(Duration(days: 5)),
        "lastVisit": DateTime.now().subtract(Duration(days: 2)),
      },
      {
        "id": 6,
        "patientId": "JCMC001239",
        "name": "Dipika Sharma",
        "age": 24,
        "phone": "+91 43210 98765",
        "roomNumber": "E-201",
        "bedNumber": "B-07",
        "admissionStatus": "Admitted",
        "department": "Pediatrics",
        "insuranceType": "Private",
        "attendingPhysician": "Dr. Nilakshi Deka",
        "photo":
            "https://images.pexels.com/photos/1181424/pexels-photo-1181424.jpeg?auto=compress&cs=tinysrgb&w=400",
        "alerts": ["DNR Status"],
        "admissionDate": DateTime.now().subtract(Duration(hours: 8)),
        "lastVisit": DateTime.now().subtract(Duration(hours: 1)),
      },
    ];

    _filteredPatients = List.from(_allPatients);

    setState(() {
      _isLoading = false;
    });
  }

  void _onSearchChanged() {
    final query = _searchController.text.trim();
    if (query != _searchQuery) {
      setState(() {
        _searchQuery = query;
        _isSearching = query.isNotEmpty;
      });
      _performSearch(query);
    }
  }

  void _performSearch(String query) {
    if (query.isEmpty) {
      setState(() {
        _filteredPatients = List.from(_allPatients);
      });
      return;
    }

    // Add to recent searches
    _addToRecentSearches(query);

    final filtered = _allPatients.where((patient) {
      final name = (patient["name"] as String).toLowerCase();
      final patientId = (patient["patientId"] as String).toLowerCase();
      final phone = (patient["phone"] as String).toLowerCase();
      final roomNumber = patient["roomNumber"]?.toString().toLowerCase() ?? '';
      final bedNumber = patient["bedNumber"]?.toString().toLowerCase() ?? '';
      final department = (patient["department"] as String).toLowerCase();

      final searchLower = query.toLowerCase();

      return name.contains(searchLower) ||
          patientId.contains(searchLower) ||
          phone.contains(searchLower) ||
          roomNumber.contains(searchLower) ||
          bedNumber.contains(searchLower) ||
          department.contains(searchLower);
    }).toList();

    setState(() {
      _filteredPatients = filtered;
    });
  }

  void _addToRecentSearches(String query) async {
    if (query.isEmpty || _recentSearches.contains(query)) return;

    setState(() {
      _recentSearches.insert(0, query);
      if (_recentSearches.length > 10) {
        _recentSearches = _recentSearches.take(10).toList();
      }
    });

    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('recent_searches', _recentSearches);
  }

  void _loadRecentSearches() async {
    final prefs = await SharedPreferences.getInstance();
    final searches = prefs.getStringList('recent_searches') ?? [];
    setState(() {
      _recentSearches = searches;
    });
  }

  void _clearRecentSearches() async {
    setState(() {
      _recentSearches.clear();
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('recent_searches');
  }

  void _onRecentSearchTap(String search) {
    _searchController.text = search;
    _searchFocusNode.unfocus();
  }

  void _removeFilter(String filter) {
    setState(() {
      _activeFilters.remove(filter);
    });
    _applyFilters();
  }

  void _showAdvancedFilters() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => AdvancedFilterBottomSheet(
        currentFilters: _advancedFilters,
        onApplyFilters: _onAdvancedFiltersApplied,
      ),
    );
  }

  void _onAdvancedFiltersApplied(Map<String, dynamic> filters) {
    setState(() {
      _advancedFilters = filters;
      _activeFilters.clear();

      // Convert advanced filters to active filter chips
      if (filters['departments'] != null) {
        _activeFilters.addAll((filters['departments'] as List).cast<String>());
      }
      if (filters['admissionStatuses'] != null) {
        _activeFilters
            .addAll((filters['admissionStatuses'] as List).cast<String>());
      }
      if (filters['insuranceTypes'] != null) {
        _activeFilters
            .addAll((filters['insuranceTypes'] as List).cast<String>());
      }
    });
    _applyFilters();
  }

  void _applyFilters() {
    List<Map<String, dynamic>> filtered = List.from(_allPatients);

    // Apply search query
    if (_searchQuery.isNotEmpty) {
      filtered = filtered.where((patient) {
        final name = (patient["name"] as String).toLowerCase();
        final patientId = (patient["patientId"] as String).toLowerCase();
        final phone = (patient["phone"] as String).toLowerCase();
        final searchLower = _searchQuery.toLowerCase();

        return name.contains(searchLower) ||
            patientId.contains(searchLower) ||
            phone.contains(searchLower);
      }).toList();
    }

    // Apply advanced filters
    if (_advancedFilters['departments'] != null) {
      final departments =
          (_advancedFilters['departments'] as List).cast<String>();
      if (departments.isNotEmpty) {
        filtered = filtered
            .where((patient) => departments.contains(patient["department"]))
            .toList();
      }
    }

    if (_advancedFilters['admissionStatuses'] != null) {
      final statuses =
          (_advancedFilters['admissionStatuses'] as List).cast<String>();
      if (statuses.isNotEmpty) {
        filtered = filtered
            .where((patient) => statuses.contains(patient["admissionStatus"]))
            .toList();
      }
    }

    if (_advancedFilters['insuranceTypes'] != null) {
      final types = (_advancedFilters['insuranceTypes'] as List).cast<String>();
      if (types.isNotEmpty) {
        filtered = filtered
            .where((patient) => types.contains(patient["insuranceType"]))
            .toList();
      }
    }

    setState(() {
      _filteredPatients = filtered;
    });
  }

  Future<void> _initializeCamera() async {
    try {
      final permission = await Permission.camera.request();
      if (!permission.isGranted) return;

      _cameras = await availableCameras();
      if (_cameras == null || _cameras!.isEmpty) return;

      final camera = _cameras!.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => _cameras!.first,
      );

      _cameraController = CameraController(
        camera,
        ResolutionPreset.medium,
        enableAudio: false,
      );

      await _cameraController!.initialize();

      setState(() {
        _isCameraInitialized = true;
      });
    } catch (e) {
      print('Camera initialization error: $e');
    }
  }

  void _toggleCamera() async {
    if (!_showCamera) {
      await _initializeCamera();
    }

    setState(() {
      _showCamera = !_showCamera;
    });
  }

  void _scanBarcode() {
    // Simulate barcode scanning
    HapticFeedback.mediumImpact();

    // Mock scanned patient ID
    final scannedId = "JCMC001234";
    _searchController.text = scannedId;
    _toggleCamera();

    // Show success feedback
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Patient ID scanned successfully'),
        backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _onPatientTap(Map<String, dynamic> patient) {
    Navigator.pushNamed(context, '/patient-profile', arguments: patient);
  }

  void _onCallPatient(Map<String, dynamic> patient) {
    // Implement call functionality
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Calling ${patient["name"]}...'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _onViewRecords(Map<String, dynamic> patient) {
    Navigator.pushNamed(context, '/medical-records', arguments: patient);
  }

  void _onScheduleAppointment(Map<String, dynamic> patient) {
    Navigator.pushNamed(context, '/appointment-scheduler', arguments: patient);
  }

  Future<void> _refreshData() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate network refresh
    await Future.delayed(Duration(seconds: 1));

    _initializeData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                // Search Header
                _buildSearchHeader(),

                // Filter Chips
                if (_activeFilters.isNotEmpty)
                  SearchFilterChipsWidget(
                    activeFilters: _activeFilters,
                    onRemoveFilter: _removeFilter,
                  ),

                // Content
                Expanded(
                  child: _buildContent(),
                ),
              ],
            ),

            // Camera Overlay
            if (_showCamera) _buildCameraOverlay(),
          ],
        ),
      ),
    );
  }

  Widget _buildSearchHeader() {
    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.scaffoldBackgroundColor,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Container(
                  decoration: BoxDecoration(
                    color: AppTheme.lightTheme.colorScheme.surface,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.3),
                    ),
                  ),
                  child: TextField(
                    controller: _searchController,
                    focusNode: _searchFocusNode,
                    decoration: InputDecoration(
                      hintText: 'Search patients by name, ID, phone...',
                      prefixIcon: Padding(
                        padding: EdgeInsets.all(3.w),
                        child: CustomIconWidget(
                          iconName: 'search',
                          color: AppTheme.lightTheme.colorScheme.onSurface
                              .withValues(alpha: 0.6),
                          size: 24,
                        ),
                      ),
                      suffixIcon: _searchQuery.isNotEmpty
                          ? IconButton(
                              onPressed: () {
                                _searchController.clear();
                                _searchFocusNode.unfocus();
                              },
                              icon: CustomIconWidget(
                                iconName: 'close',
                                color: AppTheme.lightTheme.colorScheme.onSurface
                                    .withValues(alpha: 0.6),
                                size: 20,
                              ),
                            )
                          : Padding(
                              padding: EdgeInsets.all(3.w),
                              child: CustomIconWidget(
                                iconName: 'mic',
                                color: AppTheme.lightTheme.colorScheme.onSurface
                                    .withValues(alpha: 0.4),
                                size: 20,
                              ),
                            ),
                      border: InputBorder.none,
                      contentPadding:
                          EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 3.w),

              // Barcode Scanner Button
              Container(
                decoration: BoxDecoration(
                  color: AppTheme.lightTheme.colorScheme.primary,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: IconButton(
                  onPressed: _toggleCamera,
                  icon: CustomIconWidget(
                    iconName: 'qr_code_scanner',
                    color: Colors.white,
                    size: 24,
                  ),
                ),
              ),
              SizedBox(width: 2.w),

              // Advanced Filter Button
              Container(
                decoration: BoxDecoration(
                  color: _activeFilters.isNotEmpty
                      ? AppTheme.lightTheme.colorScheme.primary
                          .withValues(alpha: 0.1)
                      : AppTheme.lightTheme.colorScheme.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _activeFilters.isNotEmpty
                        ? AppTheme.lightTheme.colorScheme.primary
                        : AppTheme.lightTheme.colorScheme.outline
                            .withValues(alpha: 0.3),
                  ),
                ),
                child: IconButton(
                  onPressed: _showAdvancedFilters,
                  icon: CustomIconWidget(
                    iconName: 'tune',
                    color: _activeFilters.isNotEmpty
                        ? AppTheme.lightTheme.colorScheme.primary
                        : AppTheme.lightTheme.colorScheme.onSurface
                            .withValues(alpha: 0.6),
                    size: 24,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildContent() {
    if (_isLoading) {
      return Center(
        child: CircularProgressIndicator(
          color: AppTheme.lightTheme.colorScheme.primary,
        ),
      );
    }

    if (!_isSearching && _searchQuery.isEmpty) {
      return Column(
        children: [
          if (_recentSearches.isNotEmpty)
            RecentSearchesWidget(
              recentSearches: _recentSearches,
              onSearchTap: _onRecentSearchTap,
              onClearAll: _clearRecentSearches,
            ),
          Expanded(
            child: EmptyStateWidget(
              type: 'initial',
              onScanPressed: _toggleCamera,
            ),
          ),
        ],
      );
    }

    if (_filteredPatients.isEmpty) {
      return EmptyStateWidget(
        type: 'no_results',
        onScanPressed: _toggleCamera,
        onRetryPressed: _refreshData,
      );
    }

    return RefreshIndicator(
      onRefresh: _refreshData,
      color: AppTheme.lightTheme.colorScheme.primary,
      child: ListView.builder(
        padding: EdgeInsets.only(top: 2.h, bottom: 10.h),
        itemCount: _filteredPatients.length,
        itemBuilder: (context, index) {
          final patient = _filteredPatients[index];
          return PatientCardWidget(
            patient: patient,
            onTap: () => _onPatientTap(patient),
            onCall: () => _onCallPatient(patient),
            onViewRecords: () => _onViewRecords(patient),
            onScheduleAppointment: () => _onScheduleAppointment(patient),
          );
        },
      ),
    );
  }

  Widget _buildCameraOverlay() {
    return Container(
      color: Colors.black,
      child: Column(
        children: [
          // Camera Header
          Container(
            padding: EdgeInsets.all(4.w),
            child: Row(
              children: [
                IconButton(
                  onPressed: _toggleCamera,
                  icon: CustomIconWidget(
                    iconName: 'close',
                    color: Colors.white,
                    size: 24,
                  ),
                ),
                Spacer(),
                Text(
                  'Scan Patient ID',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    color: Colors.white,
                  ),
                ),
                Spacer(),
                SizedBox(width: 12.w),
              ],
            ),
          ),

          // Camera Preview
          Expanded(
            child: _isCameraInitialized && _cameraController != null
                ? Stack(
                    children: [
                      CameraPreview(_cameraController!),

                      // Scanning Frame
                      Center(
                        child: Container(
                          width: 60.w,
                          height: 30.h,
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: AppTheme.lightTheme.colorScheme.primary,
                              width: 2,
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CustomIconWidget(
                                iconName: 'qr_code',
                                color: Colors.white.withValues(alpha: 0.8),
                                size: 15.w,
                              ),
                              SizedBox(height: 2.h),
                              Text(
                                'Position patient ID within frame',
                                style: AppTheme.lightTheme.textTheme.bodySmall
                                    ?.copyWith(
                                  color: Colors.white.withValues(alpha: 0.8),
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  )
                : Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        CircularProgressIndicator(
                          color: AppTheme.lightTheme.colorScheme.primary,
                        ),
                        SizedBox(height: 2.h),
                        Text(
                          'Initializing camera...',
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
          ),

          // Scan Button
          Container(
            padding: EdgeInsets.all(6.w),
            child: ElevatedButton(
              onPressed: _isCameraInitialized ? _scanBarcode : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.lightTheme.colorScheme.primary,
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 2.h),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomIconWidget(
                    iconName: 'camera_alt',
                    color: Colors.white,
                    size: 20,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Scan Now',
                    style: AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
