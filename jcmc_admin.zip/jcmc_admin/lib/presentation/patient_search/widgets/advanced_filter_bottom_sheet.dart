import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class AdvancedFilterBottomSheet extends StatefulWidget {
  final Map<String, dynamic> currentFilters;
  final Function(Map<String, dynamic>) onApplyFilters;

  const AdvancedFilterBottomSheet({
    Key? key,
    required this.currentFilters,
    required this.onApplyFilters,
  }) : super(key: key);

  @override
  State<AdvancedFilterBottomSheet> createState() =>
      _AdvancedFilterBottomSheetState();
}

class _AdvancedFilterBottomSheetState extends State<AdvancedFilterBottomSheet> {
  late Map<String, dynamic> _filters;
  final List<String> _departments = [
    'Cardiology',
    'Neurology',
    'Orthopedics',
    'Pediatrics',
    'Emergency',
    'General Medicine',
    'Surgery',
    'Gynecology',
    'Dermatology',
    'Psychiatry'
  ];
  final List<String> _admissionStatuses = [
    'Admitted',
    'Outpatient',
    'Emergency',
    'Discharged',
    'Scheduled'
  ];
  final List<String> _insuranceTypes = [
    'Government',
    'Private',
    'Self-Pay',
    'Corporate',
    'International'
  ];

  @override
  void initState() {
    super.initState();
    _filters = Map<String, dynamic>.from(widget.currentFilters);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 80.h,
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.scaffoldBackgroundColor,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        children: [
          // Handle
          Container(
            margin: EdgeInsets.only(top: 2.h),
            width: 12.w,
            height: 0.5.h,
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.onSurface
                  .withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Header
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Row(
              children: [
                Text(
                  'Advanced Filters',
                  style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Spacer(),
                TextButton(
                  onPressed: _clearAllFilters,
                  child: Text(
                    'Clear All',
                    style: AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
                      color: AppTheme.lightTheme.colorScheme.error,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Filters Content
          Expanded(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildDateRangeSection(),
                  SizedBox(height: 3.h),
                  _buildDepartmentSection(),
                  SizedBox(height: 3.h),
                  _buildAdmissionStatusSection(),
                  SizedBox(height: 3.h),
                  _buildInsuranceTypeSection(),
                  SizedBox(height: 3.h),
                  _buildAttendingPhysicianSection(),
                  SizedBox(height: 3.h),
                  _buildMedicalConditionsSection(),
                  SizedBox(height: 10.h),
                ],
              ),
            ),
          ),

          // Apply Button
          Container(
            padding: EdgeInsets.all(4.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.scaffoldBackgroundColor,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.1),
                  blurRadius: 10,
                  offset: Offset(0, -2),
                ),
              ],
            ),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _applyFilters,
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 2.h),
                ),
                child: Text('Apply Filters'),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDateRangeSection() {
    return ExpansionTile(
      title: Text(
        'Date Range',
        style: AppTheme.lightTheme.textTheme.titleMedium,
      ),
      leading: CustomIconWidget(
        iconName: 'date_range',
        color: AppTheme.lightTheme.colorScheme.primary,
        size: 24,
      ),
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      decoration: InputDecoration(
                        labelText: 'From Date',
                        suffixIcon: CustomIconWidget(
                          iconName: 'calendar_today',
                          color: AppTheme.lightTheme.colorScheme.onSurface
                              .withValues(alpha: 0.6),
                          size: 20,
                        ),
                      ),
                      readOnly: true,
                      onTap: () => _selectDate(context, 'fromDate'),
                    ),
                  ),
                  SizedBox(width: 4.w),
                  Expanded(
                    child: TextFormField(
                      decoration: InputDecoration(
                        labelText: 'To Date',
                        suffixIcon: CustomIconWidget(
                          iconName: 'calendar_today',
                          color: AppTheme.lightTheme.colorScheme.onSurface
                              .withValues(alpha: 0.6),
                          size: 20,
                        ),
                      ),
                      readOnly: true,
                      onTap: () => _selectDate(context, 'toDate'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildDepartmentSection() {
    return ExpansionTile(
      title: Text(
        'Department',
        style: AppTheme.lightTheme.textTheme.titleMedium,
      ),
      leading: CustomIconWidget(
        iconName: 'local_hospital',
        color: AppTheme.lightTheme.colorScheme.primary,
        size: 24,
      ),
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
          child: Wrap(
            spacing: 2.w,
            runSpacing: 1.h,
            children: _departments.map((department) {
              final isSelected =
                  (_filters['departments'] as List?)?.contains(department) ??
                      false;
              return FilterChip(
                label: Text(department),
                selected: isSelected,
                onSelected: (selected) =>
                    _toggleFilter('departments', department, selected),
                selectedColor: AppTheme.lightTheme.colorScheme.primary
                    .withValues(alpha: 0.2),
                checkmarkColor: AppTheme.lightTheme.colorScheme.primary,
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildAdmissionStatusSection() {
    return ExpansionTile(
      title: Text(
        'Admission Status',
        style: AppTheme.lightTheme.textTheme.titleMedium,
      ),
      leading: CustomIconWidget(
        iconName: 'bed',
        color: AppTheme.lightTheme.colorScheme.primary,
        size: 24,
      ),
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
          child: Wrap(
            spacing: 2.w,
            runSpacing: 1.h,
            children: _admissionStatuses.map((status) {
              final isSelected =
                  (_filters['admissionStatuses'] as List?)?.contains(status) ??
                      false;
              return FilterChip(
                label: Text(status),
                selected: isSelected,
                onSelected: (selected) =>
                    _toggleFilter('admissionStatuses', status, selected),
                selectedColor: AppTheme.lightTheme.colorScheme.primary
                    .withValues(alpha: 0.2),
                checkmarkColor: AppTheme.lightTheme.colorScheme.primary,
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildInsuranceTypeSection() {
    return ExpansionTile(
      title: Text(
        'Insurance Type',
        style: AppTheme.lightTheme.textTheme.titleMedium,
      ),
      leading: CustomIconWidget(
        iconName: 'account_balance_wallet',
        color: AppTheme.lightTheme.colorScheme.primary,
        size: 24,
      ),
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
          child: Wrap(
            spacing: 2.w,
            runSpacing: 1.h,
            children: _insuranceTypes.map((type) {
              final isSelected =
                  (_filters['insuranceTypes'] as List?)?.contains(type) ??
                      false;
              return FilterChip(
                label: Text(type),
                selected: isSelected,
                onSelected: (selected) =>
                    _toggleFilter('insuranceTypes', type, selected),
                selectedColor: AppTheme.lightTheme.colorScheme.primary
                    .withValues(alpha: 0.2),
                checkmarkColor: AppTheme.lightTheme.colorScheme.primary,
              );
            }).toList(),
          ),
        ),
      ],
    );
  }

  Widget _buildAttendingPhysicianSection() {
    return ExpansionTile(
      title: Text(
        'Attending Physician',
        style: AppTheme.lightTheme.textTheme.titleMedium,
      ),
      leading: CustomIconWidget(
        iconName: 'person',
        color: AppTheme.lightTheme.colorScheme.primary,
        size: 24,
      ),
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
          child: TextFormField(
            decoration: InputDecoration(
              labelText: 'Doctor Name',
              hintText: 'Enter doctor name',
              prefixIcon: CustomIconWidget(
                iconName: 'search',
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.6),
                size: 20,
              ),
            ),
            onChanged: (value) {
              setState(() {
                _filters['attendingPhysician'] = value;
              });
            },
          ),
        ),
      ],
    );
  }

  Widget _buildMedicalConditionsSection() {
    return ExpansionTile(
      title: Text(
        'Medical Conditions',
        style: AppTheme.lightTheme.textTheme.titleMedium,
      ),
      leading: CustomIconWidget(
        iconName: 'medical_services',
        color: AppTheme.lightTheme.colorScheme.primary,
        size: 24,
      ),
      children: [
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
          child: TextFormField(
            decoration: InputDecoration(
              labelText: 'Condition Keywords',
              hintText: 'e.g., diabetes, hypertension',
              prefixIcon: CustomIconWidget(
                iconName: 'search',
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.6),
                size: 20,
              ),
            ),
            maxLines: 2,
            onChanged: (value) {
              setState(() {
                _filters['medicalConditions'] = value;
              });
            },
          ),
        ),
      ],
    );
  }

  void _toggleFilter(String filterKey, String value, bool selected) {
    setState(() {
      if (_filters[filterKey] == null) {
        _filters[filterKey] = <String>[];
      }

      final List<String> filterList = List<String>.from(_filters[filterKey]);
      if (selected) {
        if (!filterList.contains(value)) {
          filterList.add(value);
        }
      } else {
        filterList.remove(value);
      }
      _filters[filterKey] = filterList;
    });
  }

  void _selectDate(BuildContext context, String dateKey) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime.now().add(Duration(days: 365)),
    );

    if (picked != null) {
      setState(() {
        _filters[dateKey] = picked;
      });
    }
  }

  void _clearAllFilters() {
    setState(() {
      _filters.clear();
    });
  }

  void _applyFilters() {
    widget.onApplyFilters(_filters);
    Navigator.pop(context);
  }
}
