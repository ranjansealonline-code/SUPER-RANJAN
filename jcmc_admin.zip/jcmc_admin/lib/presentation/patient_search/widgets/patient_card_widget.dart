import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class PatientCardWidget extends StatelessWidget {
  final Map<String, dynamic> patient;
  final VoidCallback? onTap;
  final VoidCallback? onCall;
  final VoidCallback? onViewRecords;
  final VoidCallback? onScheduleAppointment;

  const PatientCardWidget({
    Key? key,
    required this.patient,
    this.onTap,
    this.onCall,
    this.onViewRecords,
    this.onScheduleAppointment,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final bool hasAlerts = (patient["alerts"] as List?)?.isNotEmpty ?? false;
    final String status = patient["admissionStatus"] ?? "Outpatient";

    return Dismissible(
      key: Key(patient["id"].toString()),
      direction: DismissDirection.startToEnd,
      background: Container(
        margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            SizedBox(width: 6.w),
            CustomIconWidget(
              iconName: 'phone',
              color: AppTheme.lightTheme.colorScheme.primary,
              size: 24,
            ),
            SizedBox(width: 4.w),
            Text(
              'Call',
              style: AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
                color: AppTheme.lightTheme.colorScheme.primary,
              ),
            ),
            Spacer(),
            CustomIconWidget(
              iconName: 'folder_open',
              color: AppTheme.lightTheme.colorScheme.primary,
              size: 24,
            ),
            SizedBox(width: 4.w),
            Text(
              'Records',
              style: AppTheme.lightTheme.textTheme.labelLarge?.copyWith(
                color: AppTheme.lightTheme.colorScheme.primary,
              ),
            ),
            SizedBox(width: 6.w),
          ],
        ),
      ),
      onDismissed: (direction) {
        // Show quick actions bottom sheet
        _showQuickActions(context);
      },
      child: Card(
        margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: BorderSide(
            color: _getStatusColor(status).withValues(alpha: 0.3),
            width: 1,
          ),
        ),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: EdgeInsets.all(4.w),
            child: Row(
              children: [
                // Patient Photo
                Container(
                  width: 15.w,
                  height: 15.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _getStatusColor(status),
                      width: 2,
                    ),
                  ),
                  child: ClipOval(
                    child: patient["photo"] != null
                        ? CustomImageWidget(
                            imageUrl: patient["photo"],
                            width: 15.w,
                            height: 15.w,
                            fit: BoxFit.cover,
                          )
                        : Container(
                            color: AppTheme.lightTheme.colorScheme.surface,
                            child: CustomIconWidget(
                              iconName: 'person',
                              color: AppTheme.lightTheme.colorScheme.onSurface
                                  .withValues(alpha: 0.6),
                              size: 8.w,
                            ),
                          ),
                  ),
                ),
                SizedBox(width: 4.w),

                // Patient Info
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              patient["name"] ?? "Unknown Patient",
                              style: AppTheme.lightTheme.textTheme.titleMedium
                                  ?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          if (hasAlerts) ...[
                            SizedBox(width: 2.w),
                            CustomIconWidget(
                              iconName: 'warning',
                              color: AppTheme.lightTheme.colorScheme.error,
                              size: 20,
                            ),
                          ],
                        ],
                      ),
                      SizedBox(height: 0.5.h),
                      Row(
                        children: [
                          Text(
                            'Age: ${patient["age"] ?? "N/A"}',
                            style: AppTheme.lightTheme.textTheme.bodySmall,
                          ),
                          SizedBox(width: 4.w),
                          if (patient["roomNumber"] != null) ...[
                            CustomIconWidget(
                              iconName: 'bed',
                              color: AppTheme.lightTheme.colorScheme.onSurface
                                  .withValues(alpha: 0.6),
                              size: 16,
                            ),
                            SizedBox(width: 1.w),
                            Text(
                              'Room ${patient["roomNumber"]}',
                              style: AppTheme.lightTheme.textTheme.bodySmall,
                            ),
                          ],
                        ],
                      ),
                      SizedBox(height: 0.5.h),
                      Row(
                        children: [
                          Container(
                            padding: EdgeInsets.symmetric(
                                horizontal: 2.w, vertical: 0.5.h),
                            decoration: BoxDecoration(
                              color: _getStatusColor(status)
                                  .withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              status,
                              style: AppTheme.lightTheme.textTheme.labelSmall
                                  ?.copyWith(
                                color: _getStatusColor(status),
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                          Spacer(),
                          Text(
                            'ID: ${patient["patientId"] ?? "N/A"}',
                            style: AppTheme.dataTextStyle(
                              isLight: true,
                              fontSize: 11,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                      if (hasAlerts) ...[
                        SizedBox(height: 1.h),
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 2.w, vertical: 0.5.h),
                          decoration: BoxDecoration(
                            color: AppTheme.lightTheme.colorScheme.error
                                .withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              CustomIconWidget(
                                iconName: 'info',
                                color: AppTheme.lightTheme.colorScheme.error,
                                size: 14,
                              ),
                              SizedBox(width: 1.w),
                              Flexible(
                                child: Text(
                                  (patient["alerts"] as List).join(', '),
                                  style: AppTheme
                                      .lightTheme.textTheme.labelSmall
                                      ?.copyWith(
                                    color:
                                        AppTheme.lightTheme.colorScheme.error,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ],
                  ),
                ),

                // Action Arrow
                CustomIconWidget(
                  iconName: 'chevron_right',
                  color: AppTheme.lightTheme.colorScheme.onSurface
                      .withValues(alpha: 0.4),
                  size: 20,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'admitted':
      case 'inpatient':
        return AppTheme.lightTheme.colorScheme.primary;
      case 'emergency':
      case 'critical':
        return AppTheme.lightTheme.colorScheme.error;
      case 'discharged':
      case 'completed':
        return AppTheme.lightTheme.colorScheme.tertiary;
      case 'outpatient':
      case 'scheduled':
        return AppTheme.lightTheme.colorScheme.secondary;
      default:
        return AppTheme.lightTheme.colorScheme.secondary;
    }
  }

  void _showQuickActions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: EdgeInsets.all(6.w),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            SizedBox(height: 3.h),
            Text(
              patient["name"] ?? "Patient Actions",
              style: AppTheme.lightTheme.textTheme.titleLarge,
            ),
            SizedBox(height: 3.h),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildQuickActionButton(
                  context,
                  'Call Patient',
                  'phone',
                  AppTheme.lightTheme.colorScheme.primary,
                  onCall,
                ),
                _buildQuickActionButton(
                  context,
                  'View Records',
                  'folder_open',
                  AppTheme.lightTheme.colorScheme.tertiary,
                  onViewRecords,
                ),
                _buildQuickActionButton(
                  context,
                  'Schedule',
                  'calendar_today',
                  AppTheme.lightTheme.colorScheme.secondary,
                  onScheduleAppointment,
                ),
              ],
            ),
            SizedBox(height: 4.h),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActionButton(
    BuildContext context,
    String label,
    String iconName,
    Color color,
    VoidCallback? onPressed,
  ) {
    return Column(
      children: [
        Container(
          width: 15.w,
          height: 15.w,
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.1),
            shape: BoxShape.circle,
          ),
          child: IconButton(
            onPressed: () {
              Navigator.pop(context);
              onPressed?.call();
            },
            icon: CustomIconWidget(
              iconName: iconName,
              color: color,
              size: 24,
            ),
          ),
        ),
        SizedBox(height: 1.h),
        Text(
          label,
          style: AppTheme.lightTheme.textTheme.labelSmall,
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
