import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class EmptyStateWidget extends StatelessWidget {
  final String type;
  final VoidCallback? onScanPressed;
  final VoidCallback? onRetryPressed;

  const EmptyStateWidget({
    Key? key,
    required this.type,
    this.onScanPressed,
    this.onRetryPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(8.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Illustration
            Container(
              width: 40.w,
              height: 40.w,
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface,
                shape: BoxShape.circle,
              ),
              child: CustomIconWidget(
                iconName: _getEmptyStateIcon(),
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.4),
                size: 20.w,
              ),
            ),
            SizedBox(height: 4.h),

            // Title
            Text(
              _getEmptyStateTitle(),
              style: AppTheme.lightTheme.textTheme.headlineSmall?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.8),
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 2.h),

            // Description
            Text(
              _getEmptyStateDescription(),
              style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.6),
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 4.h),

            // Action Buttons
            if (type == 'no_results') ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  OutlinedButton.icon(
                    onPressed: onScanPressed,
                    icon: CustomIconWidget(
                      iconName: 'qr_code_scanner',
                      color: AppTheme.lightTheme.colorScheme.primary,
                      size: 20,
                    ),
                    label: Text('Scan Patient ID'),
                  ),
                  SizedBox(width: 4.w),
                  ElevatedButton.icon(
                    onPressed: onRetryPressed,
                    icon: CustomIconWidget(
                      iconName: 'refresh',
                      color: Colors.white,
                      size: 20,
                    ),
                    label: Text('Try Again'),
                  ),
                ],
              ),
            ] else if (type == 'initial') ...[
              ElevatedButton.icon(
                onPressed: onScanPressed,
                icon: CustomIconWidget(
                  iconName: 'qr_code_scanner',
                  color: Colors.white,
                  size: 20,
                ),
                label: Text('Scan Patient ID'),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(horizontal: 6.w, vertical: 2.h),
                ),
              ),
            ],

            if (type == 'initial') ...[
              SizedBox(height: 3.h),
              Text(
                'or start typing to search',
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurface
                      .withValues(alpha: 0.5),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _getEmptyStateIcon() {
    switch (type) {
      case 'no_results':
        return 'search_off';
      case 'error':
        return 'error_outline';
      case 'loading':
        return 'hourglass_empty';
      default:
        return 'person_search';
    }
  }

  String _getEmptyStateTitle() {
    switch (type) {
      case 'no_results':
        return 'No Patients Found';
      case 'error':
        return 'Something Went Wrong';
      case 'loading':
        return 'Searching Patients...';
      default:
        return 'Search for Patients';
    }
  }

  String _getEmptyStateDescription() {
    switch (type) {
      case 'no_results':
        return 'Try different keywords, scan a patient ID, or check your filters.';
      case 'error':
        return 'Unable to load patient data. Please check your connection and try again.';
      case 'loading':
        return 'Please wait while we search through patient records.';
      default:
        return 'Enter patient name, ID, phone number, or room number to find patient records quickly.';
    }
  }
}
